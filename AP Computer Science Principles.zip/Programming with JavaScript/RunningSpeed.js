/* Write a program that asks the user how far they ran (in miles)
 * and then how long it took them (in minutes), and print out
 * their speed in miles per hour. */
 
var MINUTES_TO_HOURS = 60;

function start(){
    println("This program produces your speed");

    var distance = readInt("How many miles did you run? ");
    println("Total miles ran: " + distance);
    
    var time = readInt("How many minutes did you run?");
    println("Total minutes ran: " + time);
    
    var milesperhour = (distance / (MINUTES_TO_HOURS/time) * 4);
    println("Miles per hour: " + milesperhour);
	
}
