/* This program should draw the French flag. The
 * left third of the canvas is blue, the middle third
 * is white, and the right third is red. */
function start(){
    var bluerectangle = new Rectangle(getWidth()/3, getHeight());
    bluerectangle.setColor (Color.blue);
    bluerectangle.setPosition(0,0);
    add(bluerectangle);
    
    var redrectangle = new Rectangle(getWidth()/3, getHeight());
    redrectangle.setColor (Color.red);
    redrectangle.setPosition(267,0);
    add(redrectangle);
}
