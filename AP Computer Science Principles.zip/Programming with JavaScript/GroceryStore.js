function start(){
    var name = readLine ("What is your Name?");
    println("Your name is: " + name);
    
    var apples = readInt("How many Apples do you want?");
    println(apples + " apples");
    
    var oranges = readInt("How many Oranages do you want?");
    println(oranges + " oranges");
    


}
