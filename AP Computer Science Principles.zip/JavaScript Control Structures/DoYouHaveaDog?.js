/* This program should declare a boolean that describes whether or
 * not you have a dog. Then you should print out an informative
 * message to the user. */
function start(){
	var have_dog = true;
	
	if (have_dog = true){
	    print("I HAVE A DOG");
	  
	}else{
	    print("I DON'T HAVE A DOG IM A STUPID HUMAN");
	}
	
	print(have_dog);
}
