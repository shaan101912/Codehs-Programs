function start(){
    var color = readLine("What color is the light? ");
    var red = "red";
    var green = "green";
    var yellow = "yellow";
    
    if(color == "green") {
        println("You can go ");
    }else if(color == "yellow"){
        println("Slow down");
    }else if(color == "red"){
	    println("Stop");
	}
	    
}
