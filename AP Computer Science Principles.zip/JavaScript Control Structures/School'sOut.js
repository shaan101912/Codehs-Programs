function start(){
    var weekday = readBoolean("Is today a weekday? ");
    var holliday = readBoolean("Is today a holliday? ");
    var weekend = readBoolean("Is it the weekend? ");
    
    if(weekend){
        println("There is no school today");
        println("true");
    }
    
    if(holliday){
        println("There is no school today");
        println("true");
    }
    
    if(weekday){
        if(holliday){
            println("There is no school today");
            println("true");
        }else {
            println("There is school today"); 
            println("false");
        }
    }
    
}
