function start()
{
    roll(100, 6, 1);	
}

function roll(num,high,low)
{
    for(var i = 0; i < num; i++)
    {
        println(random_num(high,low));   
        
    }
}

function random_num(high,low)
{
    var random = Randomizer.nextInt(low, high);
    return random;
}
