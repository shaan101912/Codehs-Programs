function start(){
    var age = readInt("What is your age");
    var teen = (age >= 13 && age <= 19);
    
    if (teen){
        print("Yes, you are a teenager");
    }else{
        print("You are not a teenager");
    }
    
}
