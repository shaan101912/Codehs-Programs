function start(){
    var value1 = readInt("What is your first roll?: ");
    var value2 = readInt("What is your second roll? ");
    
    var rolledDoubles = value1 == value2;
    
    if (rolledDoubles){
        print(rolledDoubles);
    }else{
        print(rolledDoubles);
    }
    
    
}
