var SIDE_LENGTH = 100;

function start()
{
    var center_square = square(SIDE_LENGTH, getWidth()/2-55, getHeight()/2-55);
    add(center_square);
}

function square(side,x,y)
{
    var sqr = new Rectangle(side , side);
    sqr.setPosition(x,y);
    sqr.setColor(random_colors());
    return sqr;
    
}

function random_colors()
{
    var color = Randomizer.nextColor();
    return color;
}
