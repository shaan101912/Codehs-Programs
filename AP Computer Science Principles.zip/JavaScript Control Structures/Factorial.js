function start(){
    var N = 5;
    for(var i = N; i <= 120; i *= N-1){
        N *= i;
        println(i);
    }
	
}
