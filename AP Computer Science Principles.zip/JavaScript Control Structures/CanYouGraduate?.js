function start(){
    var coolio = readBoolean("Are you coolio? ");
    var fail = readBoolean("Did you fail every Class? ");
    var grad = coolio && fail;
    
    println("Can Graduate: " + grad);
}

