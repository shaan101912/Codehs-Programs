function start(){
    var points = readInt("Input how many points per game you get ");
    var rebounds = readInt("Input how many rebounds per game you get ");
    var assists = readInt("Input how many assists you get per game ");
    
    var enough_points = points >= 25;
    var points_enough_2 = (points >= 10) && (points < 25);
    var enough_rebounds = rebounds >= 10;
    var enough_assists = assists >= 10;
    
    var all_star = (enough_points || (rebounds && enough_assists && points_enough_2));
    
    print(all_star);
    
}

