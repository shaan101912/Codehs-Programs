var SIDES_ON_DICE = 6;

function start() 
{
    for(var i = 1; i <= 6; i++)
    {
        for(var c = 1; c <=6; c++)
        {
            println(i + "," + c);
        }
    }
}
