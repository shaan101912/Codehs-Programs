turnLeft();

move();
move();

turnLeft();
turnLeft();
turnLeft();

move();
move();
move();

turnLeft();
turnLeft();
turnLeft();

move();

turnLeft();
move();
