function start(){
    if(facingEast()){
		jumpHurdle();
	}
}

function jumpHurdle(){
    for(var i=0; i<13; i++){
        turnLeft();
        move();
        turnRight();
        move();
        turnRight();
        move();
        turnLeft();
    }
}
