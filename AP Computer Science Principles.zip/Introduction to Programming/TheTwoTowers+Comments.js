function start(){
    moveTotower();
    makeTower();
    jump();
    moveTotower();
    makeTower();
}


// This function causes karel to move to the tower base.
function moveTotower(){
    move();
    turnLeft();
}

// This function allows Karel to turn right.
function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}

// This function allows Karel to build the tower.
function makeTower(){
    putBall();
    move();
    putBall();
    move();
    putBall();
    move();
    turnRight();
}

// This function maakes karel get off the tower
function jump(){
    move();
    turnRight();
    move();
    move();
    move();
    turnLeft();
}
