function start(){
    startPosition(); 
    
    while(frontIsClear()) {
        if(rightIsBlocked()){
            putBall();
            move();
        }
        if(rightIsClear()){
            move();
        }
    }
    if(frontIsBlocked()){
        putBall();
    }
}

function startPosition(){
    move();
    move();
    move();
    move();
    move();
    turnLeft();
    
}
