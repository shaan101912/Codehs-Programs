while (frontIsClear()){
    if(colorIs(Color.red)){
        paint(Color.blue);
        if(frontIsClear()){
            move();    
        }
       
        
    } 
    if(colorIs(Color.blue)){
        paint(Color.red);
        if(frontIsClear()){
            move();    
        }
        
    }
    
     
}
