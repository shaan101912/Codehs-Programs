putBall();
move();
turnRight();
move();
putBall();
turnLeft();
move();
turnRight();
move();
putBall();
turnLeft();








function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft(); 
}
