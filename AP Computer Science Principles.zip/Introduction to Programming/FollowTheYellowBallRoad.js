// Follow the yellow ball road!
// Karel moves until it's not on a tennis ball.
function start() {
    while(ballsPresent()){
        move();
    }
	
}
