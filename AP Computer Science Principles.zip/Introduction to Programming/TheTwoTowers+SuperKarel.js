function start(){
	movetoTower();
	buildTower();
	jump();
	movetoTower();
	buildTower();
}

// this function moves Karel to the base of the tower.
function movetoTower(){
    move();
    turnLeft();
}

// this function makes karel build the tower
function buildTower(){
    putBall();
    move();
    putBall();
    move();
    putBall();
    move();
    turnRight();
}

//this function makes karel get off the tower
function jump(){
    move();
    turnRight();
    move();
    move();
    move();
    turnLeft();
}
