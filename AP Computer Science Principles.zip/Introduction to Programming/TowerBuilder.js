//This completes all worlds
function start() {
    makeTower();
    movetoPosition();
}
//this makes towers and brings karel back down
function makeTower(){
    turnLeft();
    putBall();
    move();
    putBall();
    move();
    putBall();
    turnAround();
    move();
    move();
    turnLeft();
}
//this brings karel to the next position
function movetoPosition(){
    while(frontIsClear()){
        move();
        if (frontIsClear()){
            move();
            makeTower();
        }
    }
}
