function start() {
    move();
    move();
    backflip();
    move();
    move();
    backflip();
}
    
function backflip() {
    turnLeft();
    turnLeft();
    turnLeft();
    turnLeft();
}
