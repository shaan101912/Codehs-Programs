function start()
{
    move();
    move();
    buryBall();
    
    move();
    move();
    buryBall();
    
    move();
    move();
    buryBall();
    
}

function buryBall()
{
    turnRight();
    move();
    move();
    move();
    
    putBall();
    turnLeft();
    turnLeft();
    move();
    move();
    move();
    turnRight();
    move();
    
}

function turnRight()
{
    turnLeft();
    turnLeft();
    turnLeft();
}
