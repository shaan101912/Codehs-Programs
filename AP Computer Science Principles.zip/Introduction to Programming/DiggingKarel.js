function start()
{
    while(frontIsClear())
    {
        while(rightIsBlocked())
        {
            move();
        }
        
        if(rightIsClear())
        {
            buryBall();   
        }
    }
    if (facingWest())
    {
        buryBall();
        buryBall();
    }
}





function buryBall()
{
    turnLeft();
    turnLeft();
    turnLeft();
    move();
    move();
    move();
    putBall();
    turnLeft();
    turnLeft();
    move();
    move();
    move();
    turnLeft();
    turnLeft();
    turnLeft();
    move();    
}
