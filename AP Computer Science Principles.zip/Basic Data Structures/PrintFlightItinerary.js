function start(){
	var list = ["San Francisco", " New York", " Chicago", " Honolulu"];
	var final = [];
	for(var i = 0; i < list.length; i++)
	{
		final.push(list[i]);
		final.push(" --> ");
	}
	
	println(final.join(""));
}
