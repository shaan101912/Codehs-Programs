function start()
{
    var arr = [1,2,3,4];
    var doubled = doubleList(arr);
    println(doubleList(arr));
    //println(doubled);
}


function doubleList(arr)
{
    var result = [];
    for (var i = 0; i< arr.length; i++)
    {
        result.push(arr[i]);  
        result.push(arr[i]); 
    }
    return result;
  
    
}
