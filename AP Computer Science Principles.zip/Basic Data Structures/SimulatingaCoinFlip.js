var flip = Randomizer.nextInt(0,1);



if(flip == 1)
{
    println("heads");
}
else
{
    println("tails");
    
}


