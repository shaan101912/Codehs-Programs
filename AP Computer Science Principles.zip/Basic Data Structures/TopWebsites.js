function start()
{
	var websites = [
		"Youtube", "PcPartPicker", 
		"Steam", "Origin"];

    println(websites[0]);
    
    websites[0] = "IHATECODEHS.gov";
	
	var idx = websites[0];
	
	println(idx);
	
	
}
