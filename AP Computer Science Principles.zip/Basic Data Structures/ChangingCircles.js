var NUM_CIRCLES = 15;
var MIN_RADIUS = 10;
var MAX_RADIUS = 40;
var DELAY = 500;

var circleRadius = Randomizer.nextInt(MIN_RADIUS,MAX_RADIUS);
var circle = new Circle(circleRadius);

function start()
{
	var arrcircle = [];
	
	
	for(var i = 0; i < 5; i++)
	{
	   circles(); 
	}
    
    setTimer(changeColor, DELAY);
}



function circles()
{
    var circleRadius = Randomizer.nextInt(MIN_RADIUS,MAX_RADIUS);
    var circle = new Circle(circleRadius);
    var xset = Randomizer.nextInt(0,getWidth());
	var yset = Randomizer.nextInt(0,getHeight());
    //circle.setColor(x);
    circle.setPosition(xset,yset);
    add(circle);
    return circle;
}

function changeColor()
{
    var setColorty = Randomizer.nextColor();
    circle.setColor(setColorty);
}
