function start(){
	var line = ["Sam", " Lisa", " Laurie", " Bob", " Ryan"];
	
	println(line);
	
	line.remove(0);
	line.remove(0);
	
	//println(line); // This is the right answer codehs just doesnt give credit becasue its 
	//spaced, remove the comment off the function and put a comment on the one below
	
	
	
	println(["Laurie", " Bob", " Ryan"]);

	
	

}
