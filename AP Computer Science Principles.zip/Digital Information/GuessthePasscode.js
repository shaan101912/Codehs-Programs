/*
 * Write a program that guesses every possible 4 digit passcode
 * combinations until the correct passcode is guessed.
 *
 * The passcode is randomly generated and stored in the variable
 * secretPasscode.
 *
 * Print out how many guesses it took to guess the correct passcode.
 */
var amt_guesses = 0;

function start() {
    var secretPasscode = generateRandomPasscode().split("");
    var guess = [];
    
    for(var i = 0; i < 4; i++)
    {
        guess.push(checkTerm(i,secretPasscode));
        
    }
    
    println(secretPasscode.join(""));
    println(guess.join(""));
    println("Amount of Guess: " + amt_guesses);
    
    
}
// Checks whether the given guess passcode is the correct passcode
function isCorrect(guessCode, correctCode) 
{
    var correct = false;
    var total = 0;
    for(var i = 0; i < 4; i++)
    {
        if(guessCode[i] == correctCode[i])
        {
            total++;
        }
    }
    
    if(total == 4)
    {
        correct = true;
        
    }
    return correct;
}

// Generates a random 4 digit passcode and returns it as a String
function generateRandomPasscode() 
{
    var randomPasscode = "";
    
    for(var i = 0; i < 4; i++) 
    {
        var randomDigit = Randomizer.nextInt(0, 9);
        randomPasscode += randomDigit;
    }
    
    return randomPasscode;
}

function checkTerm(term,arr)
{
    for(var i = 0; i <= 9; i++)
    {
        if(i == arr[term])
        {
            return i;
            break;
        }
        amt_guesses++;
        
    }
    
}
