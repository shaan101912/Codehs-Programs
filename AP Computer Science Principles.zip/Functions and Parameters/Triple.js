function start(){
    var cool = readInt("What number do you want me to triple ");
    triple(cool);
	
}

function triple(x){
	var tripleX = x * 3;
	println(tripleX);
}
