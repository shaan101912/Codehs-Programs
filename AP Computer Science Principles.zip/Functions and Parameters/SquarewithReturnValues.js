function start(){
    var x = square(5);
   
}

function square(x){
    var newnew = x *x;
    return (newnew);
    
    
}
