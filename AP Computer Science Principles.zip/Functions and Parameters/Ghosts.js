// Constants for main ghost body
var HEAD_RADIUS = 35;
var BODY_WIDTH = HEAD_RADIUS * 2;
var BODY_HEIGHT = 60;
var NUM_FEET = 3;
var FOOT_RADIUS = (BODY_WIDTH) / (NUM_FEET * 2); 

// Constants for eyes
var PUPIL_RADIUS = 4;
var PUPIL_LEFT_OFFSET = 8;
var PUPIL_RIGHT_OFFSET = 20;
var EYE_RADIUS = 10;
var EYE_OFFSET = 14;

/* Write a comment here about your overall program */
function start(){
    var centerX = getWidth()/2;
    var centerY = getHeight()/2;
    drawGhost(centerX, centerY, Color.red);
    drawGhost(100,100, Color.green);
    drawGhost(300, 200, Color.black);
    drawGhost(40, 300, Color.orange);
    drawGhost(300, 50, Color.yellow);
}


function drawCircle(radius, color, x, y){
    var circle = new Circle(radius);
    circle.setColor(color);
    circle.setPosition(x, y);
    add(circle);
}

function drawRect(width, height, color, x, y){
    var rect = new Rectangle(width, height);
    rect.setColor(color);
    rect.setPosition(x, y);
    add(rect);
}

function drawGhost(cx, cy, color){
    drawCircle(HEAD_RADIUS, color, cx, cy);
    drawRect(BODY_WIDTH, BODY_HEIGHT, color,cx - (BODY_WIDTH / 2), cy);
     
     for(var i = 0; i < NUM_FEET; i++){
         var start = -NUM_FEET + 1 + (i*2);
         drawCircle(FOOT_RADIUS, color,
         cx + start*FOOT_RADIUS,
         cy + BODY_HEIGHT);
    }
    drawCircle(EYE_RADIUS, Color.white,cx - EYE_OFFSET, cy);
    
    drawCircle(EYE_RADIUS, Color.white,cx + EYE_OFFSET, cy);
    
    drawCircle(PUPIL_RADIUS, Color.blue,cx - PUPIL_LEFT_OFFSET, cy);
    
    drawCircle(PUPIL_RADIUS, Color.blue,cx + PUPIL_RIGHT_OFFSET, cy);
}
