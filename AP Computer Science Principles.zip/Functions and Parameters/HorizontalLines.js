function horizontalLine(y1,x2){
    var x1 = 0;
    var line = new Line(x1, y1, x2, y1);
    add(line);
}
function start(){
horizontalLine(100, 200);
horizontalLine(200, 100);   
horizontalLine(300, 20);
	
	
}
