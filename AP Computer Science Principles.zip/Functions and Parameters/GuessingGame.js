var num = Randomizer.nextInt(0, 100);

function start()
{
    println(num + "<- This is the number so you can test the code each time");
    
    while (true)
    {
        var start =  readLine("Type : START : to begin the game: ");
        if (start == "START")
        {
            game();
            break;
        }else
        {
            println("Hey stupid type START not something else...");
        }
    }
}

function game()
{
    while(true)
    {
        var numguess = readInt("Guess a number between 0 and 100: ");
        numguess;
        if (numguess < num)
        {
            println("Too Low");
        
        }else if (numguess > num) 
        {
            println("Too High");
        
        }else
        {
            println("CORRECT!");
            
            break;
        }
        
    }}

