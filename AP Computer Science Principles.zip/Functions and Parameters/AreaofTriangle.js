var BASEe = readInt("What do yo want the base to be?  ");
var HEIGHTe = readInt("What do you want the Height to be?  ");

function start(){
    triangleArea (BASEe,HEIGHTe);
}

function triangleArea(BASE, HEIGHT){
	var area = 1/2 * BASE * HEIGHT;
	println(area);
}
