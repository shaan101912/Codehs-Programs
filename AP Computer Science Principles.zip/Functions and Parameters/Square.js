function start(){
    var cool = readInt("What number do you want me to square ");
    square(cool);
	
}

function square(x){
	var doubleX = x * x;
	println(doubleX);
}
