function start(){
    var x = triple(4);
}

function triple(x){
    var triple = 3*x;
    return (triple);
}
