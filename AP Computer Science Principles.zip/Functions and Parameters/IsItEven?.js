var SENTINEL = 0;

// Prints whether the entered number is even or odd
function start(){
    while (true){
        var num = readInt("Enter a number: ");
        if (num == SENTINEL){
        break;
        }

        if (isEven(num)){
            println("Even");
        }else{ 
          println("Odd");
        }
    }
    println("Done!");
}

function isEven(x){
    return x % 2 == 0;
}
