var INCHES_TO_CM = 2.54;
var CM_TO_METERS = 0.01;
var FEET_TO_INCHES = 12;

var FEETe = readInt("How many feet?  ");
var INCHESe = readInt("How many inches?  ");

function start(){
    convertHeightToMeters(FEETe,INCHESe);
}

function convertHeightToMeters(FEET, INCHES){
	var meters = (FEET * FEET_TO_INCHES  + INCHES) * INCHES_TO_CM * CM_TO_METERS;
	println(meters);
}
