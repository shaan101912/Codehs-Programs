function start(){
	sum(1, 1);
	
	sum(5, 10);
	
	var x = 10;
	var y = 104;
	sum(x, y);
}

function sum(first, second){
	var total = first + second;
	println(total);
}
