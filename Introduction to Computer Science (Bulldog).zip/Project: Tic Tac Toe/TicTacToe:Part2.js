var WIDTH = 400;
var HEIGHT = 400;

setSize(WIDTH, HEIGHT);

var WINNING_LINE_WIDTH = 10;
var WINNING_LINE_COLOR = Color.red;

var whichXorO = true;

var example = 1;

var whichXorO1 = 0;

function start()
{
    //Makes Tic Tac Toe Grid
    makeGrid();
    
    //Allows for the testing of locations : Activate if needed
    //locationTester();
    
    mouseClickMethod(handleClick);
    
    
}

//Used for testing locations of entities if activated in start function
function locationTester()
{
    //Circle location tester for O
    createCircle(200,335);
    
    //X location tester for X
    createX(275,275);    

}

//Creates the Lines necessary for making the Grid
function makeGrid()
{
    lines(getWidth()*(1/3),getHeight(),getWidth()*(1/3),0);
    lines(getWidth()*(2/3),getHeight(),getWidth()*(2/3),0);
    lines(0,getHeight()*(1/3),getWidth(),getHeight()*(1/3));
    lines(0,getHeight()*(2/3),getWidth(),getHeight()*(2/3));
}

//Creates a line on input : Used for the Grid
function lines(x1,y1,x2,y2)
{
    var line = new Line(x1, y1, x2, y2);
    line.setLineWidth(4);
    add(line);
    
    return(line);
}

//Creates a Circle on input
function createCircle(x,y)
{
     var circle = new Circle((getHeight()*(1/3))/2-9);
     circle.setPosition(x,y);
     circle.setBorderWidth(8);
     circle.setColor(Color.WHITE);
     add(circle);
}
    
//Creates an X by using one inputed location and manipulating it on two lines 
function createX(x1,y1)
{
    var lineLeft = new Line(x1, y1, x1 + (getWidth()/3)-12, y1 + (getHeight()/3)-12);         
    lineLeft.setLineWidth(4);
    add(lineLeft);
    
    var lineRight = new Line(x1 + (getWidth()/3)-12 , y1 , x1 , y1 + (getHeight()/3)-12);
    lineRight.setLineWidth(4);
    add(lineRight);

    
}
    
//Finds the Location of the click and puts the proper Shape 
function handleClick(e)
{
    //Creates variables out of the X and Y locations of the Mouse Click
    var getX = e.getX();
    var getY = e.getY();
    
    //Creates Boundaries and spawn locations for O :  if there is still space
    if (example = 1)
    {
        if(whichXorO)
        {
            //Row 1  
            if(getX < getWidth()*(1/3))    //Box column 1
            {
                if(getY < getHeight()*(1/3))
                {
                    createCircle(65,65);
                    whichXorO1++;
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(1/3))
                    {
                        createCircle(200,65);    
                        whichXorO1++;
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3)) 
                {
                    if(getY < getHeight()*(1/3))
                    {
                        createCircle(335,65);
                        whichXorO1++;
                    }
                }
            }
        
            //Row 2
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY < getHeight()*(2/3))
                {
                    if(getY > getHeight()*(1/3))
                    {
                        createCircle(65,200);
                        whichXorO1++;
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            createCircle(200,200);
                            whichXorO1++;  
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            createCircle(335,200);
                            whichXorO1++;
                        }
                    }
                }
            }
        
            //Row 3
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY > getHeight()*(2/3))
                {
                    createCircle(65,335);
                    whichXorO1++;
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        createCircle(200,335);
                        whichXorO1++;
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        createCircle(335,335);
                        whichXorO1++;
                    }
                }
            }
        }
        whichXorO = !whichXorO;
    }
    
    
    //Creates Boundaries and spawn locations for X : if there is still space
    if (example = 1)
    {
        if(whichXorO)
        {
            //Row 1  
            if(getX < getWidth()*(1/3))    //Box column 1
            {
                if(getY < getHeight()*(1/3))
                {
                    createX(5,5);
                    whichXorO1++;
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(1/3))
                    {
                        createX(140,5);    
                        whichXorO1++;
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3)) 
                {
                    if(getY < getHeight()*(1/3))
                    {
                        createX(275,5);
                        whichXorO1++;
                    }
                }
            }
        
            //Row 2
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY < getHeight()*(2/3))
                {
                    if(getY > getHeight()*(1/3))
                    {
                        createX(5,140);
                        whichXorO1++;
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            createX(140,140);
                            whichXorO1++;  
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            createX(275,140);
                            whichXorO1++;
                        }
                    }
                }
            }
        
            //Row 3
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY > getHeight()*(2/3))
                {
                    createX(5,275);
                    whichXorO1++;
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        createX(140,275);
                        whichXorO1++;
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        createX(275,275);
                        whichXorO1++;
                    }
                }
            }
        } 
        whichXorO = !whichXorO;
    }
    whichXorO = !whichXorO;
}









