var WIDTH = 400;
var HEIGHT = 400;
setSize(WIDTH, HEIGHT);

var WINNING_LINE_WIDTH = 10;
var WINNING_LINE_COLOR = Color.red;

function start()
{
    makeGrid();


	
}

function makeGrid()
{
    lines(getWidth()*(1/3),getHeight(),getWidth()*(1/3),0);
    lines(getWidth()*(2/3),getHeight(),getWidth()*(2/3),0);
    lines(0,getHeight()*(1/3),getWidth(),getHeight()*(1/3));
    lines(0,getHeight()*(2/3),getWidth(),getHeight()*(2/3));
}

function lines(x1,y1,x2,y2)
{
    var line = new Line(x1, y1, x2, y2);
    line.setLineWidth(5);
    add(line);
    
    return(line);
}
