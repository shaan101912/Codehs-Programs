//Code for Tic Tac Toe Game

//Sets up the Canvas
var WIDTH = 400;
var HEIGHT = 400;
setSize(WIDTH, HEIGHT);

//Boolean to help with alternations of X and O
var whichXorO = true;

//Used for filling in Blank statements
var example = 1;

//Keeps Track of total number of placed objects
var whichXorO1 = 0;

//Winning line variables
var WINNING_LINE_WIDTH = 10;
var WINNING_LINE_COLOR = Color.red;

//Holds the values for each Box
var Row1Box1 = 0;
var Row1Box2 = 0;
var Row1Box3 = 0;

var Row2Box1 = 0;
var Row2Box2 = 0;
var Row2Box3 = 0;

var Row3Box1 = 0;
var Row3Box2 = 0;
var Row3Box3 = 0;

//Allows only one winning line to be drawn
var finish = true;


function start()
{
    //Makes Tic Tac Toe Grid
    makeGrid();
    
    //Allows for the testing of locations : Activate if needed
    //locationTester();
    
    //Handles the Location of Click and Places X or O
    mouseClickMethod(handleClick);
    
    
    //Runs the Function to place the Winning Line
    //In Timer to Keep the Function Refreshing
    setTimer(winningLine, 15); 
    
    
    
    
}

//Used for testing locations of entities if activated in start function
function locationTester()
{
    //Circle location tester for O
    createCircle(200,335);
    
    //X location tester for X
    createX(275,275);    
    
    //Line Tester
    winningLinecreater(335,0,335,getHeight());

}

//Creates the Lines necessary for making the Grid
function makeGrid()
{
    lines(getWidth()*(1/3),getHeight(),getWidth()*(1/3),0);
    lines(getWidth()*(2/3),getHeight(),getWidth()*(2/3),0);
    lines(0,getHeight()*(1/3),getWidth(),getHeight()*(1/3));
    lines(0,getHeight()*(2/3),getWidth(),getHeight()*(2/3));
}

//Creates a line on input : Used for the Grid
function lines(x1,y1,x2,y2)
{
    var line = new Line(x1, y1, x2, y2);
    line.setLineWidth(4);
    add(line);
    
    return(line);
}

//Creates a Circle on input
function createCircle(x,y)
{
     var circle = new Circle((getHeight()*(1/3))/2-9);
     circle.setPosition(x,y);
     circle.setBorderWidth(8);
     circle.setColor(Color.WHITE);
     add(circle);
}
    
//Creates an X by using one inputed location and manipulating it on two lines 
function createX(x1,y1)
{
    var lineLeft = new Line(x1, y1, x1 + (getWidth()/3)-12, y1 + (getHeight()/3)-12);         
    lineLeft.setLineWidth(4);
    add(lineLeft);
    
    var lineRight = new Line(x1 + (getWidth()/3)-12 , y1 , x1 , y1 + (getHeight()/3)-12);
    lineRight.setLineWidth(4);
    add(lineRight);

    
}

function winningLinecreater(x1,y1,x2,y2)
{
    var lineWin = new Line(x1, y1, x2, y2);
    lineWin.setLineWidth(WINNING_LINE_WIDTH);
    lineWin.setColor(WINNING_LINE_COLOR);
    add(lineWin);

}

//Creates a Red line on the Winning Row
function winningLine()
{
    //Waits for the Board to fill up
    if(whichXorO1 >= 5)
    {
        //Checks if A line has not been Drawn
        if(finish)
        {
            //Diagonal top left to Bottom Right
            if(Row1Box1 == Row2Box2)
            {
                if(Row1Box1 == Row3Box3)
                {
                    if(Row2Box2 == Row3Box3)
                    {
                        if(Row1Box1 != 0)
                        {
                            if(Row2Box2 != 0)
                            {
                                if(Row3Box3 != 0)
                                {
                                    winningLinecreater(0,0,getWidth(),getHeight());
                                    finish = !finish;
                                }
                            }
                        }
                    }
                }
            }
        
            //Diagonal top right to Bottom Left
            if(Row1Box3 == Row2Box2)
            {
                if(Row1Box3 == Row3Box1)
                {
                    if(Row2Box2 == Row3Box1)
                    {
                        if(Row1Box3 != 0)
                        {
                            if(Row2Box2 != 0)
                            {
                                if(Row3Box1 != 0)
                                {
                                    winningLinecreater(getWidth(),0,0,getHeight());
                                    finish = !finish;
                                }
                            }
                        }
                    }
                }
               
    
            //Diagonal Across Row1
            if(Row1Box1 == Row1Box2)
            {
                if(Row1Box1 == Row1Box3)
                {
                    if(Row1Box2 == Row1Box3)
                    {
                        if(Row1Box1 != 0)
                        {
                            if(Row1Box2 != 0)
                            {
                                if(Row1Box3 != 0)
                                {
                                    winningLinecreater(0,70,getWidth(),70); 
                                    finish = !finish;
                                }
                            }
                        }
                    }
                }
            }
    
            //Diagonal Across Row2
            if(Row2Box1 == Row2Box2)
            {
                if(Row2Box1 == Row2Box3)
                {
                    if(Row2Box2 == Row2Box3)
                    {
                        if(Row2Box1 != 0)
                        {
                            if(Row2Box2 != 0)
                            {
                                if(Row2Box3 != 0)
                                {
                                    winningLinecreater(0,200,getWidth(),200);
                                    finish = !finish;
                                }
                            }
                        }
                    }
                }
            }
    
            //Diagonal Across Row3
            if(Row3Box1 == Row3Box2)
            {
                if(Row3Box1 == Row3Box3)
                {
                    if(Row3Box2 == Row3Box3)
                    {
                        if(Row3Box1 != 0)
                        {
                            if(Row3Box2 != 0)
                            {
                                if(Row3Box3 != 0)
                                {
                                    winningLinecreater(0,330,getWidth(),330);
                                    finish = !finish;
                                }
                            }
                        }
                    }
                }
            }
    
            // Diagonal Top to Bottom period 1 
            if(Row1Box1 == Row2Box1)
            {
                if(Row1Box1 == Row3Box1)
                {
                    if(Row2Box1 == Row3Box1)
                    {
                        if(Row1Box1 != 0)
                        {
                            if(Row2Box1 != 0)
                            {
                                if(Row3Box1 != 0)
                                {
                                    winningLinecreater(65,0,65,getHeight());
                                    finish = !finish;
                                }
                            }
                        }
                    }
                }
            }
    
            // Diagonal Top to Bottom period 2 
            if(Row1Box2 == Row2Box2)
            {
                if(Row1Box2 == Row3Box2)
                {
                    if(Row2Box2 == Row3Box2)
                    {
                        if(Row1Box2 != 0)
                        {
                            if(Row2Box2 != 0)
                            {
                                if(Row3Box2 != 0)
                                {
                                    winningLinecreater(200,0,200,getHeight());
                                    finish = !finish;
                                }
                            }
                        }
                    }  
              
                }
            }
    
            // Diagonal Top to Bottom period 3 
            if(Row1Box3 == Row2Box3)
            {
                if(Row1Box3 == Row3Box3)
                {
                    if(Row2Box3 == Row3Box3)
                    {
                        if(Row1Box3 != 0)
                        {
                            if(Row2Box3 != 0)
                            {
                                if(Row3Box3 != 0)
                                {
                                    winningLinecreater(335,0,335,getHeight());
                                    finish = !finish;
                                }
                            }
                        }
                    }
                }
            }
        }
        
    }
}


//Finds the Location of the click and puts the proper Shape 
function handleClick(e)
{
    //Creates variables out of the X and Y locations of the Mouse Click
    var getX = e.getX();
    var getY = e.getY();
    
    //Creates Boundaries and spawn locations for O :  if there is still space
    if (whichXorO1<9)
    {
        if(whichXorO)
        {
            //Row 1  
            if(getX < getWidth()*(1/3))    //Box column 1
            {
                if(getY < getHeight()*(1/3))
                {
                    if(Row1Box1 == 0)
                    {
                        createCircle(65,65);
                        whichXorO1++;
                        Row1Box1++;
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(1/3))
                    {
                        if(Row1Box2 == 0)
                        {
                            createCircle(200,65);    
                            whichXorO1++;
                            Row1Box2++;
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3)) 
                {
                    if(getY < getHeight()*(1/3))
                    {
                        if(Row1Box3 == 0)
                        {
                            createCircle(335,65);
                            whichXorO1++;
                            Row1Box3++;
                        }
                    }
                }
            }
        
            //Row 2
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY < getHeight()*(2/3))
                {
                    if(getY > getHeight()*(1/3))
                    {
                        if(Row2Box1 == 0)
                        {
                            createCircle(65,200);
                            whichXorO1++;
                            Row2Box1++;
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            if(Row2Box2 == 0) 
                            {
                                createCircle(200,200);
                                whichXorO1++; 
                                Row2Box2++;
                            }
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            if(Row2Box3 == 0)
                            {
                                createCircle(335,200);
                                whichXorO1++;
                                Row2Box3++;
                            }
                        }
                    }
                }
            }
        
            //Row 3
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY > getHeight()*(2/3))
                {
                    if(Row3Box1 == 0)
                    {
                        createCircle(65,335);
                        whichXorO1++;
                        Row3Box1++;
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        if(Row3Box2 == 0)
                        {
                            createCircle(200,335);
                            whichXorO1++;
                            Row3Box2++;
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        if(Row3Box3 == 0)
                        {
                            createCircle(335,335);
                            whichXorO1++;
                            Row3Box3++;
                        }
                    }
                }
            }
        }
        whichXorO = !whichXorO;
    }
    
    
    //Creates Boundaries and spawn locations for X : if there is still space
    if (whichXorO1<9)
    {
        if(whichXorO)
        {
            //Row 1  
            if(getX < getWidth()*(1/3))    //Box column 1
            {
                if(getY < getHeight()*(1/3))
                {
                    if(Row1Box1 == 0)
                    {
                        createX(5,5);
                        whichXorO1++;
                        Row1Box1++;
                        Row1Box1++;
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(1/3))
                    {
                        if(Row1Box2 == 0)
                        {
                            createX(140,5);    
                            whichXorO1++;
                            Row1Box2++;
                            Row1Box2++;
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3)) 
                {
                    if(getY < getHeight()*(1/3))
                    {
                        if(Row1Box3 == 0)
                        {
                            createX(275,5);
                            whichXorO1++;
                            Row1Box3++;
                            Row1Box3++;
                        }
                    }
                }
            }
        
            //Row 2
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY < getHeight()*(2/3))
                {
                    if(getY > getHeight()*(1/3))
                    {
                        if(Row2Box1 == 0) 
                        {
                            createX(5,140);
                            whichXorO1++;
                            Row2Box1++;
                            Row2Box1++;
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            if(Row2Box2 == 0) 
                            {
                                createX(140,140);
                                whichXorO1++;  
                                Row2Box2++;
                                Row2Box2++;
                            }
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY < getHeight()*(2/3))
                    {
                        if(getY > getHeight()*(1/3))
                        {
                            if(Row2Box3 == 0)
                            {
                                createX(275,140);
                                whichXorO1++;
                                Row2Box3++;
                                Row2Box3++;
                            }
                        }
                    }
                }
            }
        
            //Row 3
            if(getX < getWidth()*(1/3))   //Box column 1
            {
                if(getY > getHeight()*(2/3))
                {
                    if(Row3Box1 == 0)
                    {
                        createX(5,275);
                        whichXorO1++;
                        Row3Box1++;
                        Row3Box1++;
                    }
                }
            }
        
            if(getX < getWidth()*(2/3))   //Box column 2
            {
                if(getX > getWidth()*(1/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        if(Row3Box2 == 0)
                        {
                            createX(140,275);
                            whichXorO1++;
                            Row3Box2++;
                            Row3Box2++;
                        }
                    }
                }
            }
        
            if(getX < getWidth()*(3/3))   //Box column 3
            {
                if(getX > getWidth()*(2/3))
                {
                    if(getY > getHeight()*(2/3))
                    {
                        if(Row3Box3 == 0)
                        {
                            createX(275,275);
                            whichXorO1++;
                            Row3Box3++;
                            Row3Box3++;
                        }
                    }
                }
            }
        } 
    }
}

