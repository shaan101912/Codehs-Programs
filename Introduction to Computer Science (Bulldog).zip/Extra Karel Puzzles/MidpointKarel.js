function start(){
    if (noBallsPresent()){
        for(var i=0; i<7; i++){
            
        }
    }
    
