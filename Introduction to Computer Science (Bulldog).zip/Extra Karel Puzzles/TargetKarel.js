//This has karel scan for the ball then build the target
function start()
    {
    scanForTarget();
    makeBottom();
    makeTop();
    makeLeft();
    makeRight();
    }
//This has Karel scan for the ball to base the target off of
function scanForTarget()
{
    while(noBallsPresent())
    {
        if(facingEast())
            {
            if(frontIsClear())
            {
                move();
            }
            if(frontIsBlocked())
            {
                turnLeft();
                move();
                turnLeft();
            }
        }
        if(facingWest())
        {
            if(frontIsClear())
            {
                move();
            }
            if(frontIsBlocked())
            {
                turnRight();
                move();
                turnRight();
            }
        }
    }
}
//Has Karel make the bottom portion of the target
function makeBottom()
{
    if(notFacingEast())
    {
        turnAround();
    }
    turnRight();
    while(frontIsClear())
    {
        move();
    }
    if(frontIsBlocked())
    {
        turnAround();
    }
    while(noBallsPresent())
    {
        putBall();
        move();
    }
}
//Has Karel make the top portion of the target
function makeTop(){
    while(frontIsClear())
    {
        move();
    }
    if(frontIsBlocked())
    {
        turnAround();
    }
    while(noBallsPresent())
    {
        putBall();
        move();
    }
}
//Has Karel make the left portion of the tower
function makeLeft()
{
    turnLeft();
    while(frontIsClear())
    {
        move();
    }
    if(frontIsBlocked())
    {
        turnAround();
    }
    while(noBallsPresent())
    {
        putBall();
        move();
    }
}
//Has Karel make the Right portion of the tower
function makeRight()
{
    while(frontIsClear())
    {
        move();
    }
    if(frontIsBlocked())
    {
        turnAround();
    }
    while(noBallsPresent())
    {
        putBall();
        move();
    }
}
