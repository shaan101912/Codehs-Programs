var CIRCLES_PER_SPLATTER = 20;
var MIN_RADIUS = 5;
var MAX_RADIUS = 25;
var DELAY = 500;
var MAX_RADIUS = 44;
var MAX_CIRCLES = 1000;
var counter = 0;

function start(){
	setTimer(draw, 10);
}

function draw(){
	drawCircle(Randomizer.nextInt(0, MAX_RADIUS),
			   Randomizer.nextColor(),
			   Randomizer.nextInt(0, getWidth()),
			   Randomizer.nextInt(0, getHeight()));
	
	counter++;
	
	if(counter == MAX_CIRCLES){
		stopTimer(draw);
	}
}

function drawCircle(radius, color, x, y){
	var circle = new Circle(radius);
	circle.setColor(color);
	circle.setPosition(x, y);
	add(circle);
	
	var circle2 = new Circle(radius);
	circle2.setColor(color);
	circle2.setPosition(x+x, y+y);
	add(circle2);
	
	var circle2w = new Circle(radius);
	circle2w.setColor(color);
	circle2w.setPosition(x+x+x+x, y+y+y+y);
	add(circle2w);
}
