/* This program displays the x and y
 * coordinates in a label on the screen
 * and updates when the mouse moves */
function start()
{
    mouseMoveMethod(onMouseMove);
 
	
}


function onMouseMove(e) 
{
	var txt = new Text("hi","20pt Arial");
	txt.setText("Mouse is at (" +
			e.getX() + ", " +
			e.getY() + ").");
	txt.setPosition(0,100);
	add(txt);
	
	removeAll();
	
	var txt = new Text("hi","20pt Arial");
	txt.setText("Mouse is at (" +
			e.getX() + ", " +
			e.getY() + ").");
	txt.setPosition(0,100);
	add(txt);
}


