/* Constants */
var START_RADIUS = 1;
var INCREMENT = 1;
var CHANGE_COLORS_AT = 10;
var circle;
var number;
var ball;

 

function start(){
    setTimer(hi,100);
}

function hi(){
    var circle = new Circle(START_RADIUS);
    circle.setRadius(START_RADIUS);
	START_RADIUS++;
	circle.setPosition(getWidth()/2 , getHeight()/2);
	circle.setColor(Randomizer.nextColor());
	add(circle);
}

