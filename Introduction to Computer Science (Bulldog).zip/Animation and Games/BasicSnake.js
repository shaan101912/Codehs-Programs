var SNAKE_WIDTH = 40;
var SNAKE_HEIGHT = 40;
var SNAKE_COLOR = Color.green;

// Constants to represent the directions
var EAST = 0;
var SOUTH = 1;
var WEST = 2;
var NORTH = 3;
var x = (getWidth()/2)-20;
var y = (getHeight()/2)-20;

var square;   

function start()
{
	square = new Rectangle(40, 40);
	square.setColor(Color.GREEN);
	square.setPosition(x, y);
	add(square);
	keyDownMethod(start2);
	//greenrectangle();
}

function start2(e) 
{

    
    if(e.keyCode == Keyboard.LEFT)
    {
        stopTimer(right);
        stopTimer(up);
        stopTimer(down);
        setTimer(left, 40);
    }

    if(e.keyCode == Keyboard.RIGHT)
    {
        stopTimer(left);
        stopTimer(up);
        stopTimer(down);
        setTimer(right, 40);
    }
    
    if(e.keyCode == Keyboard.UP)
    {
        stopTimer(left);
        stopTimer(down);
        stopTimer(right);
        setTimer(up, 40);
    }
    
    if(e.keyCode == Keyboard.DOWN)
    {
        stopTimer(up);
        stopTimer(left);
        stopTimer(right);
        setTimer(down, 40);
    }
}

function left()
{
	square.move(-5, 0);
}
	
	
function right()
{
	square.move(5, 0);
}

function up()
{
	square.move(0, -5);
}

function down()
{
	square.move(0, 5);
}

/*function greenrectangle()
{
    var rectangle = new Rectangle(40, 40);
    rectangle.setColor(Color.GREEN);
	rectangle.setPosition(x, y);
	add(rectangle);
}*/
