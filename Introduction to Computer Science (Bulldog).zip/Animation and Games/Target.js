var x;
var horizontalLine; 
var verticalLine;
var y;

function start()
{
    mouseMoveMethod(target);
    
    mouseClickMethod(addBall12);
}

function target(e)
{
    x = e.getX();
    y = e.getY();
    
    removeAll(target);
    
    horizontalLine = new Line(0, y, getWidth(), y);
    horizontalLine.setLineWidth(1);
    add(horizontalLine);
    verticalLine = new Line(x, 0, x, getHeight());
    verticalLine.setLineWidth(1);
    add(verticalLine);
    
    var txt = new Text("hi","20pt Arial");
	txt.setText("Mouse is at (" +
			e.getX() + ", " +
			e.getY() + ").");
	txt.setPosition(0,100);
	add(txt);
}

function addBall12(e) 
{
    var ball3 = new Circle (10);
    ball3.setPosition(e.getX(),e.getY());
    ball3.setColor(Color.red);
    add(ball3);
}

//line.setEndpoint(x2, y2)
