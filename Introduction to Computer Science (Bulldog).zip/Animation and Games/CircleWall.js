// Constants
var RADIUS = 20;
var DELAY = 40;
var i = 20;
var n = 20;
var o = 60;



function start(){
    setTimer(allRows, DELAY);
}

function drawcircle(x,y,color){
    var circle = new Circle (RADIUS);
    circle.setPosition(x,y);
    circle.setColor(color);
    add(circle);
}

function row(y){
    drawcircle(20,y,Color.RED);
    drawcircle(60,y,Color.BLACK);
    drawcircle(100,y,Color.RED);
    drawcircle(140,y,Color.BLACK);
    drawcircle(180,y,Color.RED);
    drawcircle(220,y,Color.BLACK);
    drawcircle(260,y,Color.RED);
    drawcircle(300,y,Color.BLACK);
    drawcircle(340,y,Color.RED);
    drawcircle(380,y,Color.BLACK);
}

function allRows(){
    if (i <= 460){
        row(i);
        i = i + 40;
    }
    else if( i > 460){
        stopTimer(allRows);
    }
}





