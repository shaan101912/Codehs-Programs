var RADIUS = 100;
var circle;
var number;
var ball;

 

function start(){
	// create the circle and number and add to the screen
	circle = new Circle(RADIUS);
	setTimer(shake,1);
	add(circle);
	
	
}


function shake(){
    circle.setColor(Randomizer.nextColor());
    circle.setPosition(Randomizer.nextInt(100, 250),Randomizer.nextInt(100, 250));
    
}


  
	

