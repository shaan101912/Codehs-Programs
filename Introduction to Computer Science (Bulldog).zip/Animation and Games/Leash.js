var BALL_RADIUS = 30;
var line;
var ball;

    

function down(e)
{
	line = new Line(getWidth()/2, getHeight()/2,
					getWidth()/2, getHeight()/2);
	
	add(line);
	
	ball = new Circle(BALL_RADIUS);
	ball.setColor(Color.YELLOW);
	ball.setPosition(getWidth()/2, getHeight()/2);
	add(ball);
	
}

function drag(e)
{
    line.setEndpoint(e.getX(), e.getY());
    ball.setPosition(e.getX(), e.getY());
    
}

function start(){
	down();
	mouseMoveMethod(drag);
}


