/* This program helps us divide a large number
 * of people into groups. We tell it how many
 * total people there are, and how many people
 * there are per group, and we figure out
 * how many groups there are, and how many
 * are left over. */
function start(){
	var people = readInt("Num people: ");
	var peoplePerGroup = readInt("People per group: ");
	
	// We must use Math.floor to make sure the result
	// is an integer
	var groups = Math.floor(people / peoplePerGroup);
	
	// The % operator helps us find the remainder
	var peopleLeft = people % peoplePerGroup;
	
	println("There are " + groups + " groups " + 
		"with " + peopleLeft + " left over.");
}

// This constant represents our currency
// conversion rate
var DOLLARS_TO_POUNDS = 0.6462;

// This program will convert dollars to pounds
function start(){
	println("This program converts USD to GBP.");
	var dollars = readFloat("USD: ");
	
	// This is how we can convert from dollars
	// to pounds
	var pounds = dollars * DOLLARS_TO_POUNDS;
	
	println("GBP: " + pounds);
}



function start(){
	var first = readInt("First: ");
	var second = readInt("Second: ");
	var sum = first + second;
	println(sum);
}
