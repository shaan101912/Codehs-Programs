function start(){
    var rolledDoubles = readInt("What did you first roll? ");
    var rolledDoublestwo = readInt("What did you get second roll? ");
    var gotdouble = rolledDoubles == rolledDoublestwo;
    println("You Rolled You doubles: " + gotdouble);
	
}

