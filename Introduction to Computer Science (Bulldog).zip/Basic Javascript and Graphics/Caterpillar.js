var NUM_CIRCLES = 15;
var Radius = (getWidth()/NUM_CIRCLES)/2;
function start(){ 
    for(var i = 0; i < NUM_CIRCLES/2; i++){
        var circleh = new Circle(Radius);
        circleh.setColor(Color.green);
        circleh.setPosition(Radius+27 + i*Radius*4,getHeight()/2);
        add(circleh);
        
        var circle = new Circle(Radius);
        circle.setColor(Color.red);
        circle.setPosition(Radius + i*Radius*4,getHeight()/2);
        add(circle);
    }
    remove(circleh);
}
