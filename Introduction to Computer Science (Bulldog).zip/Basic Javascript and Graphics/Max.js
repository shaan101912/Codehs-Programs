var num1 = readInt("What do you want the first number to be ?");
var num2 = readInt("What do you want the second number to be? ");

function start(){
    var maxim = max(num1,num2);
    println("The max is " + maxim);
}

function max(first,second){
    if (first > second) {
        return first;
    }else {
        return second;
    }
}    

    






