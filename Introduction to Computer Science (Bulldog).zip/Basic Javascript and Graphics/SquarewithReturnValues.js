var num = readInt("What number should we sqaure?  ");
function start(){
    var y =num;
    println(square(y));
   
	
}

function square(x){
	var squareX = x * x;
	return squareX;
	println(squareX);
}
