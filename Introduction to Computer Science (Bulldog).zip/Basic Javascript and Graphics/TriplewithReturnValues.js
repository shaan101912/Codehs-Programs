var num = readInt("What number should we triple?  ");
function start(){
    var y =num;
    println(triple(y));
   
	
}

function triple(x){
	var tripleX = x * 3;
	return tripleX;
	println(tripleX);
}
