// This program counts to one hundred by
// twos using a for loop.
function start(){
	for(var i = 0; i <= 100; i += 2){
		println(i);
	}
}
function start(){
	for(var i = 10; i >= 0; i--){
		println(i);
	}
}
