var SIDES_ON_DICE = 6;

function start() {
    for(var i = 1; i <= SIDES_ON_DICE; i++){
        println(1 + ","  + i);
    }
    
    for(var i = 1; i <= SIDES_ON_DICE; i++){
        println(2 + ","  + i);
    }
    
    for(var i = 1; i <= SIDES_ON_DICE; i++){
        println(3 + ","  + i);
    }
    
    for(var i = 1; i <= SIDES_ON_DICE; i++){
        println(4 + ","  + i);
    }
    
    for(var i = 1; i <= SIDES_ON_DICE; i++){
        println(5 + ","  + i);
    }
    
    for(var i = 1; i <= SIDES_ON_DICE; i++){
        println(6 + ","  + i);
    }
     
	
}
