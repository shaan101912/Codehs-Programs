function start(){
    //Stores number of initial Apples
    var numApples = 20;
    println("Number of apples: " + numApples);
    
    // Stores number of initial Oranges
    var numOranges = 15;
    println("Number of oranges: " + numOranges);
    
    //set number of apples to zero
    var numApples = 0;
    println("Number of apples: " + numApples);
    
    //Sets number of oranges to zero
    var numOranges = 0;
    println("Number of oranges: " + numOranges);
}
