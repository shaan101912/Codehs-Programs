// This program reads a password from the 
// user and checks if it matches the secret
// password. We print out a message in
// either case.
function start(){
	var secretPassword = "abc123";
	var password = readLine("Password: ");
	if(password == secretPassword){
		println("Passwords match.");
	}else{
		println("Passwords don't match.");
	}
}

function start(){
	var num = readInt("Number: ");
	if(num % 2 == 0){
		println("Number is even.");
	}else{
		println("Number is odd.");
	}
}

function start(){
	var name = readLine("Enter name: ");
	if(name == "Jeremy"){
		println("Great name.");
	}	
}

function start(){
	var number = readInt("Number: ");
	if(number < 0){
		println("Number is negative.");
	}
}
