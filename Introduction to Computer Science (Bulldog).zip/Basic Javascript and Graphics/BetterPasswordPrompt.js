var SECRET = "abc123";

function start(){
    while(true){
        var pass = readLine("What is your password? ");
        if (pass != SECRET){
        println("Your password is wrong ");
        }
        if (pass == SECRET){
            println("Ur good");
            break;
        }
    }
	
}






