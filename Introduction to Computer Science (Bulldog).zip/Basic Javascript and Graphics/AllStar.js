function start(){
    var Pointsgame = readInt("What Was your points per game? ");
    var rebounds = readInt("How many points di you get from rebounds? ");
    var assists = readInt("How many points di you grt from assists? ");
    var totalpts = Pointsgame == 25 || Pointsgame >= 10 && rebounds >= 10 && assists >= 10 ;
    println("Allstar: " + totalpts);
}

