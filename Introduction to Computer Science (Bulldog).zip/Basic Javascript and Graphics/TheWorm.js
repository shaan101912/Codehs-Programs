var NUM_CIRCLES = 15;
var Radius = (getWidth()/NUM_CIRCLES)/2;
function start(){ 
    for(var i = 0; i < NUM_CIRCLES; i++){
        var circle = new Circle(Radius);
        circle.setPosition(Radius + i*Radius*2,getHeight()/2);
        add(circle);
    }
}
