/* This program will play a simple guessing game.
 * The user will guess, and the computer should print if
 * the guess was too high, too low, or correct.
 */
function start() {
    var randomnum = Randomizer.nextInt(1, 100);
    var num = readInt("What number between 1 and 100 do you want to guess? ");
    if(num > randomnum ){
        println("The Number was too high try again  ");
    }
    if(num < randomnum ){
        println("The Number was too low  ");
    }
    if(num == randomnum){
        println("YOU GUESSED RIGHT!!");
    }
    
}
