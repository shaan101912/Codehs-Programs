var COST_OF_SHIRT = 15;
function start(){
	var shirts = readInt("How many shirts would you like to buy?");
	println("Number of TShirts: " + shirts);
	println("Total Price: " + shirts * COST_OF_SHIRT);
	
	
	
}



