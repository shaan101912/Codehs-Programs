function start(){
    for(var i = 1; i <=100 ; i++){
        var roll = Randomizer.nextInt(1,6);
        println("You rolled a " + roll);
    }
}


