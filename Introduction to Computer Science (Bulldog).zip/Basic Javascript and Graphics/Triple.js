function start(){
    var cool = readInt("What number do you want me to square ");
    triple(cool);
	
}

function triple(x){
	var doubleX = x * 3;
	println(doubleX);
}
