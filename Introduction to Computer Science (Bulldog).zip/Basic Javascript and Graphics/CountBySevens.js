function start(){
	for(var i = 0; i <= 500; i += 7){
		println(i);
	}
}
//function start(){
//	for(var i = 10; i >= 0; i--){
//		println(i);
//	}
//}
