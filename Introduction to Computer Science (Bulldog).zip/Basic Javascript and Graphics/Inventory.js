var STARTING_ITEMS_IN_INVENTORY = 20;
var numItems = STARTING_ITEMS_IN_INVENTORY;
var firstT = readInt("How many did you take first time? ");
var secondT = readInt("How many did you take the second time?" );
var thirdT = readInt("How many did you take the third time? ");
//var fourthT = readInt("How many did you take the fourth time? ");
//var fiveT = readInt("How many did you take the fifth time? ");



function start(){
    println("You have this many items to start: 20 ");
    println("You took this many items the first time: " + firstT);
    println("Now you have this many items: " + (STARTING_ITEMS_IN_INVENTORY-firstT));
    println("You took this many items the Second time: " + secondT);
    println("Now you have this many items: " + (STARTING_ITEMS_IN_INVENTORY-firstT-secondT));
    println("You took this many items the third time: " + thirdT);
    println("Now you have this many items: " + (STARTING_ITEMS_IN_INVENTORY-firstT-secondT-thirdT));
}






