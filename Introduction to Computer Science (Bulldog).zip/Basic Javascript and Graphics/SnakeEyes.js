function start(){
	var snakeEyes = 1;
	
	while (true){
	    var roll = Randomizer.nextInt(1,6);
	    println("(" + roll + "," + roll + ")");
	    if (roll == snakeEyes){
	        break;
	}
}
}

