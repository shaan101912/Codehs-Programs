var LIGHT_RADIUS = 35;
var STOPLIGHT_WIDTH = 120;
var STOPLIGHT_HEIGHT = 350;
var BUFFER = 100;
var GRAY_COLOR = "#737071";
var centerX = getWidth() / 3+5;
var centerY = getHeight() / 8;



function graySquare(){
    var rect = new Rectangle(120,350);
    rect.setPosition(centerX, centerY);
    rect.setColor(GRAY_COLOR);
    add(rect);
}



function drawCircle(color, x, y){
	var circle = new Circle(35);
	circle.setColor(color);
	circle.setPosition(x, y);
	add(circle);
}



function start(){
    graySquare();
    drawCircle(Color.green, getWidth()/2, 350);
	drawCircle(Color.red, getWidth()/2, 125);
	drawCircle(Color.yellow, getWidth()/2, getHeight()/2-2);
    
}



