var SIDE_LENGTH = 100;

function start(){
        var colorz = Randomizer.nextColor();
        var rect = new Rectangle(SIDE_LENGTH,SIDE_LENGTH);
        rect.setPosition(getWidth()/2,getHeight()/2);
        rect.setColor(colorz);
        add(rect);

}
