/* Constants representing the radius of the top, middle,
 * and bottom snowball. */
//var BOTTOM_RADIUS = 100;
//var MID_RADIUS = 60;
//var TOP_RADIUS = 30;

function start(){
	var centerX = getWidth()/2;
	var centerY = getHeight()/2;
	var lowerY = centerY * 2;
	
	//bottom
	var ball = new Circle(100);
	ball. setColor(Color.grey);
	ball.setPosition(centerX,lowerY-100);
	add(ball);
	
	
	var ball = new Circle(60);
	ball. setColor(Color.grey);
	ball.setPosition(centerX,lowerY-255);
	add(ball);
	
	var ball = new Circle(30);
	ball. setColor(Color.grey);
	ball.setPosition(centerX,lowerY-340);
	add(ball);
	
}
