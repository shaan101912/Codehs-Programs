function start(){
    var MIN = readInt("What is the first number? ");
    var MAX = readInt("What is the second number? ");
    var sum = 0;
    for(var i = MIN; i <= MAX; i++){
        sum += i;
    }
    println("The sum of all these numbers is... " + sum);
}


