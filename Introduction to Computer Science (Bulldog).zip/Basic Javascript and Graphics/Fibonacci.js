var MAX = 1000;
var n1 = 1;
var n2 = 2;

function start(){
    println("1");
    println(n1);
    println(n2);
    while(n1 + n2 <= MAX) {
        var next = n1 + n2;
        n1 = n2;
        n2 = next;
        println(next);
    }
    
}
