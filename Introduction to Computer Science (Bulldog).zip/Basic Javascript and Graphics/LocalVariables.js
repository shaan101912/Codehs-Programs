// A local variable is a variable that only exists in a function
