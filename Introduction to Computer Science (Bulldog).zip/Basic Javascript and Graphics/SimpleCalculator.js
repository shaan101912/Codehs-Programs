// Let's write a program that adds two numbers
function start(){
	var first = readInt("First: ");
	var second = readInt("Second: ");
	var sum = first + second;
	println(sum);
}
