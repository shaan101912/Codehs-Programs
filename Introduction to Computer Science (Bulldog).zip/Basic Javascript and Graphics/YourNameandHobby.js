/* This program should print out your 
 * name, and a hobby you have */
function start(){
    println("My name is Coolio the duoodio");
    println("I like to use computers");
}

// Sample output:
//
// My name is Jeremy
// I like to juggle
//
