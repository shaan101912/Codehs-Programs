// This program reads a number from the
// user and prints out whether it is
// even or odd using the modulus operator.
function start(){
	var num = readInt("Number: ");
	if(num % 2 == 0){
		println("Number is even.");
	}else{
		println("Number is odd.");
	}
}

function start(){
	var name = readLine("Enter name: ");
	if(name == "Jeremy"){
		println("Great name.");
	}	
}

function start(){
	var number = readInt("Number: ");
	if(number < 0){
		println("Number is negative.");
	}
}
