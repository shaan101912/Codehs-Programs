// This program reads the users name
// and checks if it is equal to "Jeremy"
function start(){
	var name = readLine("Enter name: ");
	if(name == "Jeremy"){
		println("Great name.");
	}	
}

function start(){
	var number = readInt("Number: ");
	if(number < 0){
		println("Number is negative.");
	}
}
