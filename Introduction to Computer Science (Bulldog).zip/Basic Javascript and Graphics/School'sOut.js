function start(){
    var weekday = readBoolean("Is today a weekday? ");
    var holliday = readBoolean("Is today a holliday? ");
    var noschool = weekday || holliday;
    println("Is there no school? " + noschool );
    
}


