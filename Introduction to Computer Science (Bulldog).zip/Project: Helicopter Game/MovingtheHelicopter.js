var DELAY = 40;
var SPEED = 5;

var copter;
var dy = SPEED;


function start(){
	// Write your code here
	setup();
	setTimer(game, DELAY);
	mouseDownMethod(onMouseDown);
	mouseUpMethod(onMouseUp);
}

function setup() {
    setBackgroundColor(Color.black);
    copter = new Rectangle(30, 15);
    copter.setPosition(getWidth()/3, getHeight()/2);
    copter.setColor(Color.blue);
    add(copter);
}

function game() {
    copter.move(0, dy);
}

function onMouseDown(e) {
    dy = -SPEED;
}

function onMouseUp(e) {
    dy = SPEED;
}
