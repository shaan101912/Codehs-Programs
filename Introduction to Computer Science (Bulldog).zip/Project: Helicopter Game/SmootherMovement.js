var DELAY = 40;
var SPEED = 5;
var MAX_DY = 12;

var OBSTACLE_WIDTH = 30;
var OBSTACLE_HEIGHT = 100;

var copter;
var dy = SPEED;
var obstacle;
var clicking = false;

function start(){
	// Write your code here
	setup();
	setTimer(game, DELAY);
	mouseDownMethod(onMouseDown);
	mouseUpMethod(onMouseUp);
}

function setup() {
    setBackgroundColor(Color.black);
    copter = new Rectangle(30, 15);
    copter.setPosition(getWidth()/3, getHeight()/2);
    copter.setColor(Color.blue);
    add(copter);
    
    addObstacles();
}

function game() {
    if (clicking) {
        dy -= 1;
        if (dy < -MAX_DY) {
            dy = -MAX_DY;
        }
    } else {
        dy += 1;
        if (dy > MAX_DY) {
            dy = MAX_DY;
        }
    }
    copter.move(0, dy);
    moveObstacles();
}

function onMouseDown(e) {
     clicking = true;
}

function onMouseUp(e) {
     clicking = false;
}

function addObstacles() {
    obstacle = new Rectangle(OBSTACLE_WIDTH, OBSTACLE_HEIGHT);
    obstacle.setColor(Color.green);
    obstacle.setPosition(getWidth(), 
            Randomizer.nextInt(0, getHeight() - OBSTACLE_HEIGHT));
    add(obstacle);
}
    
function moveObstacles() {
    obstacle.move(-SPEED, 0);
    if(obstacle.getX() < 0) {
        obstacle.setPosition(getWidth(), 
            Randomizer.nextInt(0, getHeight() - OBSTACLE_HEIGHT));
    }
}
