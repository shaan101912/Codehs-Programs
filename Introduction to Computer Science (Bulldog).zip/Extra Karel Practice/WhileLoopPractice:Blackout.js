function start() {
    for(var i=0; i<15;i++){
        while (facingEast()){
            if(noBallsPresent()){
                putBall();
            }
            if(frontIsClear()){
                move();
            }
            if(frontIsBlocked()){
                if(noBallsPresent()){
                    putBall();
                }
                turnLeft();
                if(frontIsClear()){
                    move();
                }
                turnLeft();
            }
        }
        while(facingWest()){
            if(noBallsPresent()){
                putBall();
            }
            if(frontIsClear()){
                move();
            }
            if(frontIsBlocked()){
                if(noBallsPresent()){
                    putBall();
                }
                turnRight();
                if(frontIsClear()){
                    move();
                }
                turnRight();
            }
        }
    }
    
}
//i should comment right?
//i should comment right?
//i should comment right?
//i should comment right?
//i should comment right?
//i should comment right?

function hi(){
    move();
}
function bye(){
    move();
}
