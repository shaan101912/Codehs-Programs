function start(){
    square();
    goToNext();
    square();
    
}

function square(){
    putBall();
    move();
    putBall();
    turnLeft();
    move();
    putBall();
    turnLeft();
    move();
    putBall();
    turnLeft();
    move();
    turnLeft();
    move();
}

function goToNext(){
    while(frontIsClear()){
        move();
    }
    if(frontIsBlocked()){
        turnAround();
        move();
        turnAround();
    }
} 
