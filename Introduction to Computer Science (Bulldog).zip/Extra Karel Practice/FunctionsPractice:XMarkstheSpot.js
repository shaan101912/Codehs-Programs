function start(){
    rightCross();
    gotoLeft();
    leftDiagonal();
    goBack();
}





































function rightCross(){
    crossPut();
    crossPut();
    crossPut();
    crossPut();
    putBall();
}

function crossPut(){
    putBall();
    turnLeft();
    move();
    turnRight();
    move();
}

function leftCross(){
    putBall();
    turnRight();
    move();
    turnLeft();
    move(); 
}


function gotoLeft(){
    turnRight();
    move();
    move();
    move();
    move();
    turnRight();
}

function leftDiagonal(){
    leftCross();
    leftCross();
    takeBall();
    leftCross();
    leftCross();
    putBall();
}

function goBack(){
    turnLeft();
    move();
    move();
    move();
    move();
    turnLeft();
}
