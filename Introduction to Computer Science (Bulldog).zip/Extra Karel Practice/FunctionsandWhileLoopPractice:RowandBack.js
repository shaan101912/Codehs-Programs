function start(){
    go();
    goBack();
}

function goBack(){
    putBall();
    turnAround();
    while(frontIsClear()){
        move();
    }
    if(frontIsBlocked()){   
        if(leftIsBlocked()){
            turnAround();
        }       
    }
    
}

function go(){
    while(frontIsClear()){
        if(noBallsPresent()){
            putBall();
            move();
        }
    }
}
