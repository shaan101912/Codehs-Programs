function start(){
    run();
}

function run(){
    for(var i=0; i<10;i++){    
        if(noBallsPresent()){
            if(frontIsClear()){    
                if(frontIsClear()){
                    move();
                }
                if(frontIsBlocked()){
                    jump();
                }
            }
        }
    }
    
}
function jump(){
    turnLeft();
    move();
    move();
    move();
    turnRight();
    move();
    turnRight();
    move();
    move();
    move();
    turnLeft();
}
