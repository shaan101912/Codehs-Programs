function start(){
    move();
    move();
    move();
    move();
    putBall();
    turnLeft();
    move();
    putBall();
    turnLeft();
    move();
    move();
    move();
    move();
    turnRight();
    move();
    turnRight();
    rowOne();
    turnLeft();
    move();
    turnLeft();
    move();
    rowTwo();
    turnRight();
    move();
    turnRight();
    move();
    rowThree();
    turnLeft();
    move();
    turnLeft();
    move();
    rowFour();
    turnRight();
    move();
    turnRight();
    move();
    putBall();
    turnLeft();
    move();
    turnRight();
}

function putMove(){
    putBall();
    move();
}

function rowOne(){
    putMove();
    putMove();
    putMove();
    putMove();
    putMove();
    putMove();
    putMove();
    putMove();
    putBall();
}

function rowTwo(){
    putMove();
    putMove();
    putMove();
    putMove();
    putMove();
    putMove();
    putBall();
}

function rowThree(){
    putMove();
    putMove();
    putMove();
    putMove();
    putBall();
}

function rowFour(){
    putMove();
    putMove();
    putBall();
}
