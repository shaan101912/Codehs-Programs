function start(){
    while(frontIsBlocked()){
	    climb();
    }
}




function climb(){
    turnLeft();
    move();
    turnRight();
    move();
}

