function start(){
    for(var i=0; i<10;i++){
        if(noBallsPresent()){
            putBall();
            if(ballsPresent()){
                if(frontIsClear()){
                    move();
                }
                if(frontIsClear()){
                    move();
                }
                if(frontIsBlocked()){
                    if(ballsPresent()){
                        takeBall();
                    }
                    if(frontIsBlocked()){
                        turnLeft();
                        move();
                        move();
                        move();
                        move();
                        if(frontIsBlocked()){
                            turnAround();
                            move();
                            move();
                            move();
                            move();
                            turnLeft();
                            putBall();
                        }
                    }
                    if(frontIsClear()){
                        turnAround();
                        move();
                        move();
                        move();
                        move();
                        turnLeft();
                    }
                    
                }
            }
        }
    }
}
    

