function start(){
    moveTo();
    if(frontIsBlocked()){
        turnLeft();
        moveTo();
        turnRight();
        
    }
	
}

function moveTo(){
    while(frontIsClear()){
        move();
    }
}
