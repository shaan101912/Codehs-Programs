function start(){
    turnLeft();
    while(frontIsClear()){
        move();
    }
	
}
