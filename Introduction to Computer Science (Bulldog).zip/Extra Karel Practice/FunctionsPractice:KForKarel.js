function start(){
    putBall();
    turnLeft();
    movePut9();
    turnAround();
    move();
    move();
    move();
    move();
    turnLeft();
    movePut();
    turnRight();
    movePut();
    turnLeft();
    move();
    turnRight();
    movePut();
    move();
    turnLeft();
    movePut();
    move();
    turnRight();
    movePut();
    turnLeft();
    move();
    turnRight();
    movePut();
    turnAround();
    move6();
    move();
    move();
    move();
    putBall();
    turnLeft();
    move();
    turnLeft();
    movePut();
    move();
    turnRight();
    movePut();
    move();
    turnLeft();
    movePut();
    move6();
    turnRight();
    move();
    move();
    turnAround();
}


function movePut(){
    move();
    putBall();
}

function movePut9(){
    movePut();
    movePut();
    movePut();
    movePut();
    movePut();
    movePut();
    movePut();
    movePut();
    movePut();
}
function move6(){
    move();
    move();
    move();
    move();
    move();
    move();
}
    
