function start(){
	var arr = ["bread", "eggs", 
			   "milk", "cookies"];
	
	for(var i = 0; i < arr.length; i++){
		var cur = arr[i];
		println(cur);
	}

	var list = ["bread", "eggs", "milk", "cookies", "bananas", "tuna", "lettuce", "yogurt", "cheese", "chicken", "cucumbers", "orange juice", "salt", "doritos", "lemonade", "apples", "paper towels", "red onion", "minced garlic", "tumeric", "donuts", "bagels", "crackers", "red pepper", "green pepper", "spinach", "canola oil", "vanilla", "flour", "brown sugar", "powdered sugar", "lime"];
	
	for(var i = 0; i < list.length; i++){
		println(list[i]);
	}

	
}
