function start(){
    var sidekicks = [];
    
    // Enter some sidekicks into the database
    sidekicks["Wonder Woman"] = "Wonder Girl";
    sidekicks["Mermaid Man"] = "Barnacle Boy";
    sidekicks["Finn the Human"] = "Jake the Dog";
    sidekicks["Batman"] = "Robin";
    sidekicks["Shaan"] = "Ashar";
    
    var MermaidmanSidekick = sidekicks["Mermaid Man"];
	println(MermaidmanSidekick);
    
    
    
}

