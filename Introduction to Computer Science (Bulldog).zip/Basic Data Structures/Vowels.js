var SENTINEL = "";

function start()
{
    var set = new Set();
    
    set.add("a");
    set.add("e");
    set.add("i");
    set.add("o");
    set.add("u");
    
    
    var letter = readLine("What letter? ");
    
    if(set.contains(letter)){
		println(letter + " is a vowel. ");
	}else
	{
	    println(letter + "is not a vowel");
	}
    
    

	
}



