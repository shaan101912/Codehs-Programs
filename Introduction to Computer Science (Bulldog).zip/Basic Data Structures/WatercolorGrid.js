var NUM_ROWS = 25;
var NUM_COLS = 20;

var ROW_HEIGHT = getHeight()/NUM_ROWS;
var COL_WIDTH = getWidth()/NUM_COLS;

var  grid;
// How many moves events it takes to get the color to be black
var NUM_MOVES = 20;

function start(){
	grid = new Grid(NUM_ROWS,NUM_COLS);
	grid.init(0);
	draw();
	mouseMoveMethod(handleClick);
}

/*
 * This will generate a shade of blue from white to black, 
 * where `val` is the number of times we have moved over 
 * a particular space.
 SHADE
*/

function getColor(val){
    var color = Color.createFromRGBL(64, 91, 122, 1 - val/NUM_MOVES);
    return color;
}


function getRow(y){
    return Math.min(grid.numRows()-1,Math.floor(y/ROW_HEIGHT));

}

function getCol(x){
    return Math.floor(x/COL_WIDTH);
}

function draw(){
    removeAll();
    for(var row = 0;row < grid.numRows();row++){
        for(var col=0;col<grid.numCols();col++){
            var info = grid.get(row,col);
            counting(row,col,info);
        }
    
}
}

function counting(row,col,val){
    var rect = new Rectangle(COL_WIDTH,ROW_HEIGHT);
    var color = Color.createFromRGBL(64, 91, 122, 1 - val/NUM_MOVES);
    rect.setColor(color);
    
    var x = col * COL_WIDTH;
    var y = row * ROW_HEIGHT;
    rect.setPosition(x,y);
    add(rect);
}

function handleClick(e){
    var row = getRow(e.getY());
    var col = getCol(e.getX());
    
    var prev = grid.get(row,col);
    grid.set(row,col, prev + 1);
    draw();
}
