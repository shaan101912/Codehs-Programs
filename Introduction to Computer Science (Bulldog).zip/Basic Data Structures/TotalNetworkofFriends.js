var initialMutual = new Set();
var finalMutual = new Set();

function start()
{
   
   initialMutual.add("Friend1");
   initialMutual.add("Friend2");
   initialMutual.add("Friend3");
   initialMutual.add("Friend4");
   initialMutual.add("Friend5");

    
    finalMutual.add("Friend1");
    finalMutual.add("Friend2");
    finalMutual.add("Friend52");
    finalMutual.add("Friend10");
    finalMutual.add("Friend4");
    
    
    println("Total Friends");
    println(totalFriends(initialMutual,finalMutual));
    //println(initialMutual + finalMutual);
    
}


function totalFriends(a, b) 
{
    a.union(b);
    println(initialMutual);
    //println(finalMutual);
}
