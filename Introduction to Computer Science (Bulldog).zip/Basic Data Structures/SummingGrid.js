var grid = new Grid(2, 3);

function start()
{
    
    var grid = new Grid(2, 3);
    
    grid.set(0, 0, 0);
	grid.set(0, 1, 1);
	grid.set(0, 2, 2);
	grid.set(1, 0, 1);
	grid.set(1, 1, 2);
	grid.set(1, 2, 3); 
    
    
    
	for(var row = 0; row < grid.numRows(); row++)
	{
		for(var col = 0; col < grid.numCols(); col++)
		{
			var elem = grid.get(row, col);
			print(elem + " ");
		}
		println("");
	}
}





	
	
