var messagesToJenny = new Set();
var messagesToTeddy = new Set();
var messagesToJohn = new Set();

function start()
{
    var textMessages = new Set();
    
    // Test out your functions
    sendMessage("Jenny", "Hi Jenny!");
    sendMessage("Jenny", "brb");
    sendMessage("Teddy", "I love you");
    sendMessage("Jenny", "Are you there?");
    
    println("Messages to Jenny:");
    var jennyMessages = getMessages("Jenny");
    println('   ');
    
    println("Messages to Teddy:");
    var teddyMessages = getMessages("Teddy");
    println('   ');
    
    println("Messages to John");
    var johnMessages = getMessages("John");
    
}

// Update textMessages to store message sent to friendName
function sendMessage(friendName, message)
{
    if(friendName == "Jenny")
    {
        messagesToJenny.add(message);
    }
    
    
    
    if(friendName == "Teddy")
    {
        messagesToTeddy.add(message);
    }
    
    
    if(friendName == "John")
    {
        messagesToJohn.add(message);
    }
    
}

// Get all the text messages sent to friendName
function getMessages(friendName)
{
    if(friendName == "Jenny")
    {
        println(messagesToJenny);
    }
    
    if(friendName == "John")
    {
        println(messagesToJohn);
    }
    
    if(friendName == "Teddy")
    {
        println(messagesToTeddy);
    }
    
}


