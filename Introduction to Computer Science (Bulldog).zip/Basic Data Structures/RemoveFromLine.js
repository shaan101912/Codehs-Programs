function start(){
	var line = ["Sam", " Lisa", " Laurie", " Bob", " Ryan"];
	
	println(line);
	
	var elem = line.remove(0);
	           line.remove(0);
	
	var line2 = ["Laurie", " Bob", " Ryan"];
	
	println(line2);
	
	

}
