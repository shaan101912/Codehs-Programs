function start(){
	var phonebook = [];
	
	// put in some numbers
	phonebook["Jeremy"] = "123-4567";
	phonebook["Zach"] = "333-3333";
	
	// get a number out
	var jeremysNumber = phonebook["Jeremy"];
	println(jeremysNumber);
	
	
	//map[key] = value;
	
}
