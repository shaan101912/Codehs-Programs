function start(){
   var initialMutual = new Set();
   
   initialMutual.add("Friend1");
   initialMutual.add("Friend2");
   initialMutual.add("Friend3");
   initialMutual.add("Friend4");
   initialMutual.add("Friend5");

    var finalMutual = new Set();
    
    finalMutual.add("Friend1");
    finalMutual.add("Friend2");
    finalMutual.add("Friend52");
    finalMutual.add("Friend10");
    finalMutual.add("Friend4");
    
    
    println("Mutual Friends");
    println(mutualFriends(initialMutual,finalMutual));
    
}

/* This function takes two people, a, b
 * which are sets of their friends.
 * It returns a new set that holds the
 * mutual friends of a and b.
 */
function mutualFriends(a, b) {

var mutualFriend = new Set();

for (var finall in a.elems()) {
    if(b.contains(finall)){
        mutualFriend.add(finall);
    }

}

return mutualFriend
}
