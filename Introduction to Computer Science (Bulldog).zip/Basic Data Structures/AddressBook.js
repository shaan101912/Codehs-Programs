function start(){
    var addressBook = {};
    
    addressBook.Nemo = "P Sherman, 42 Wallaby Way, Sydney";
    addressBook.Luna = "20 Ottery Street, Devon, England";
    addressBook.Fred = "301 Cobblestone Way, Bedrock, CA";
    
    println(addressBook.Nemo);
    
    addressBook.Nemo = "124 Conch Street, Bikini Bottom, Pacific Ocean";
    
    println(addressBook.Nemo);
    

}
