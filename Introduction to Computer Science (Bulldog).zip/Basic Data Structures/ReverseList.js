function start()
{
    var arr = [1,2,3,4,5];
    var reverse = reverseList(arr);
    println(reverse);
}

function reverseList(arr)
{
    var newArr = [];
    for(var i = arr.length; i > 0; i--)
    {
        newArr.push(arr.pop());
    }
    return newArr;
}
