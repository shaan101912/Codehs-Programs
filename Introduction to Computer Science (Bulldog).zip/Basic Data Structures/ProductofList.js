function start()
{
	var arr = [1, 8, 3, 4, 2, 9];
	
	var prod= 1;
	
	for(var i = 0; i < arr.length; i++){
		var cur = arr[i];
	    prod *= cur;
	}
	
	println(prod);
	
}

















































/*function start(){
	var arr = [1, 8, 123, 103, 992, 
			   21, 2, 2, 144, 523, 
			   13, 90, 77, 12, 13];
	
	var sum = 0;
	
	for(var i = 0; i < arr.length; i++){
		var cur = arr[i];
		sum += cur;
	}
	
	println(sum);
	
}

function start(){
	var arr = ["bread", "eggs", 
			   "milk", "cookies"];
	
	for(var i = 0; i < arr.length; i++){
		var cur = arr[i];
		println(cur);
	}

	var list = ["bread", "eggs", "milk", "cookies", "bananas", "tuna", "lettuce", "yogurt", "cheese", "chicken", "cucumbers", "orange juice", "salt", "doritos", "lemonade", "apples", "paper towels", "red onion", "minced garlic", "tumeric", "donuts", "bagels", "crackers", "red pepper", "green pepper", "spinach", "canola oil", "vanilla", "flour", "brown sugar", "powdered sugar", "lime"];
	
	for(var i = 0; i < list.length; i++){
		println(list[i]);
	}

	
}

*/
