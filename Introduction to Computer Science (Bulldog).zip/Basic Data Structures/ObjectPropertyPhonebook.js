function start(){
	var phonebook = {};
	phonebook.Sam = "111-1111";
	
	println(phonebook.Sam);
	
	phonebook.Sam = "444-4444";
	println(phonebook.Sam);
}
