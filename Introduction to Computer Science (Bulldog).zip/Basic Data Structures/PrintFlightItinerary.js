function start(){
	var list = ["San Francisco -> ", " New York -> ", " Chicago -> ", " Honolulu  "];
	
	for(var i = 0; i < list.length; i++)
	{
		print(list[i]);
	}
}
