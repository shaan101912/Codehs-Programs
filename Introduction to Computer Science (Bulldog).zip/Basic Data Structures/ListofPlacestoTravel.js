function start()
{
	var travelList = ["Czech Republic", "Russia", "France", "Germany", "Netherlands"];
	
	println(travelList[2]);
}
