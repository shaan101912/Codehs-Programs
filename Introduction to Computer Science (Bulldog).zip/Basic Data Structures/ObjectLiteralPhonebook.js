function start(){
	var phonebook = {
		Jeremy: "123-4567",
		Zach: "333-3333"
	};
	
	println(phonebook['Jeremy']);
}
