var DIAGONAL_TOP_LEFT_BOTTOM_RIGHT = 0;
var DIAGONAL_BOTTOM_LEFT_TOP_RIGHT = 1;

function start()
{
    getDiagonal(DIAGONAL_TOP_LEFT_BOTTOM_RIGHT);
    
    println("     ");
    
    getDiagonal(DIAGONAL_BOTTOM_LEFT_TOP_RIGHT);
	
}


function getDiagonal(whichDiagonal)
{
    var grid = new Grid(3, 3);
    
    grid.set(0, 0, 0);
	grid.set(0, 1, 1);
	grid.set(0, 2, 2);
	grid.set(1, 0, 1);
	grid.set(1, 1, 2);
	grid.set(1, 2, 3); 
    grid.set(2, 0, 2);
	grid.set(2, 1, 3);
	grid.set(2, 2, 4); 
    
    
	
    
    var arr1 = [];
    var arr2 = [];
    
    //These access values in the correst order but for a grid that is 3 x 3
    
    if (whichDiagonal == "0")
    {
        arr1.push(grid.get(0, 0));
        arr1.push(grid.get(1, 1));
        arr1.push(grid.get(2, 2));
        
        print(arr1);
        
    } 
    
    if (whichDiagonal == "1")
    {
        arr2.push(grid.get(0, 2));   
        arr2.push(grid.get(1, 1));
        arr2.push(grid.get(0, 2));
        
        print(arr2);
    }

    
    
    
}

    
    
    
    



    
