//What happens is that I first move the balls over
//then I use if balls present at the new pile and 
//then move the balls back plus 1.
function start(){
    move();
    moveBalls();
    move();
    turnAround();
    add();
    goBack();
}
//moves ball to new position
function moveBalls(){
    while (ballsPresent()){
        takeBall();
        move();
        putBall();
        turnAround();
        move();
        turnAround();
    }
}
//moves balls back plus 1
function add(){
    while (ballsPresent()){
        takeBall();
        move();
        putBall();
        putBall();
        turnAround();
        move();
        turnAround();
    }
}

function goBack(){
    move();
    move();
    turnAround();
}
    
