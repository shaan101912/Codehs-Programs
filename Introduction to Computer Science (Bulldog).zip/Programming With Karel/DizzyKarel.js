function start(){
    for(var i=0; i<32; i++){
        turnLeft();
    }
}
