function start(){
	//here Karel is jumping 4 hurdles
    for(var i=0; i<5; i++){
        jumpHurdle();
    }
}

// here is a function for jumping a hurdle
function jumpHurdle(){
    move();
    move();
    turnLeft();
    move();
    turnRight();
    move();
    turnRight();
    move();
    turnLeft();
}
