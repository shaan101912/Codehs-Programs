//Has karel get the ball and bring it back
function start() {
    getBall();
    goBack();
    putBall();
}

//has karel go to get the ball
function getBall(){
    turnLeft();
    move();
    move();
    move();
    move();
    turnRight();
    move();
    move();
    takeBall();
    turnAround();
}

//has karel go end position
function goBack(){
    move();
    move();
    turnLeft();
    move();
    move();
    move();
    move();
    turnLeft();
}
