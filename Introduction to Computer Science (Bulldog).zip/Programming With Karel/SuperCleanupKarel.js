function start() {
    for(var i=0; i<15;i++){
        while (facingEast()){
            if(ballsPresent()){
                takeBall();
            }
            if(frontIsClear()){
                move();
            }
            if(frontIsBlocked()){
                if(ballsPresent()){
                    takeBall();
                }
                turnLeft();
                if(frontIsClear()){
                    move();
                }
                turnLeft();
            }
        }
        while(facingWest()){
            if(ballsPresent()){
                takeBall();
            }
            if(frontIsClear()){
                move();
            }
            if(frontIsBlocked()){
                if(ballsPresent()){
                    takeBall();
                }
                turnRight();
                if(frontIsClear()){
                    move();
                }
                turnRight();
            }
        }
    }
    
}
//i should comment right?
//i should comment right?
//i should comment right?
//i should comment right?
//i should comment right?
//i should comment right?

function hi(){
    move();
}
function bye(){
    move();
}



