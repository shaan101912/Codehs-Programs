function start(){
    move();
    while (ballsPresent()){
        takeBall();
        move();
        putBall();
        turnAround();
        move();
        turnAround();
    }
}
