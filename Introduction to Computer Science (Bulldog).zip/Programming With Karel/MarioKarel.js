function start(){
    turnLeft();
    move();
    move();
    move();
    turnRight();
    move();
    collectCoins();
    jump();
    collectCoins();
    jump();
    collectCoins();
    jump();
    collectCoins();
    turnRight();
    move();
    move();
    move();
    turnLeft();
}


function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}

function collectCoins(){
    takeBall();
    takeBall();
}
function jump(){
    turnLeft();
    move();
    turnRight();
    move();
    move();
    turnRight();
    move();
    turnLeft();
}
