function start(){
    for (var i=0; i<26; i++){
        if (noBallsPresent())   
            if (leftIsBlocked()){
                move();
            if (leftIsClear()){
                turnLeft();
                move();
                turnLeft();
                putBall();
            }    
            if (ballsPresent()){
                takeBall();
                movetoWall();
                turnAround();
            }
        }
    }
}

function movetoWall(){
    while (frontIsClear()){
        move()
    }
}
   
