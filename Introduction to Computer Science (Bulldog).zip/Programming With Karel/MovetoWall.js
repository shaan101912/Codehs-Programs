function start(){
	while(frontIsClear()){
		move();
	}
}
