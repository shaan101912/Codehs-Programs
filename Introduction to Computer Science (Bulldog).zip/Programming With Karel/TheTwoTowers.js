function start(){
	move();
	stackBalls();
	jumpDown();
	stackBalls();
}

function stackBalls(){
    turnLeft();
    putMove();
    putMove();
    putMove();
    turnRight();
}
function putMove(){
    putBall();
    move();
}

function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}

function jumpDown(){
    move();
    turnRight();
    move();
    move();
    move();
    turnLeft();
    move();
}
