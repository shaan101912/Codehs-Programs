/* This program draws a big tower from Karel's starting spot */
function start(){
    getintoPosition();
    while(frontIsClear()){
        putBall();
        move();
    }
    makeTower();
    putBall();
    
}

function getintoPosition(){
    if(facingEast()){
        turnLeft();
    }
    if (facingSouth()){
        turnAround();
    }
    if(facingWest()){
        turnRight();
    } 
}

function makeTower(){
    while(frontIsClear()){
        putBall();
        move();
    }
}
