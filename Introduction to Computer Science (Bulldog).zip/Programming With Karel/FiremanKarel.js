turnRight();
move();
move();
move();
turnLeft();
function turnRight() {
    turnLeft();
    turnLeft();
    turnLeft();                 
}
