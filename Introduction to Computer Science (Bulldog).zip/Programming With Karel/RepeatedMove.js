for(var i = 0; i < 9; i++){
	move();
}
