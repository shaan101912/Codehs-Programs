//This has karel complete the task.
function start() {
    for (var i=0; i<32;i++){
        moveToCorner();
    }
    turnLeft();
    putBall();
}

//This has Karel move to the corner and turn.
function moveToCorner(){
    turnAtCorner();
    while (frontIsClear()){
        move();
    }
}

//This function defines the turn and ball placement when turning.
function turnAtCorner(){
    if (frontIsBlocked()){
        putBall();
        turnLeft();
    }
    
}



