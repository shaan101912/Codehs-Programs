/* Constants for bricks */
var NUM_ROWS = 8;
var CURRENT_ROW = 1;
var START_ROW = CURRENT_ROW;
var BRICK_TOP_OFFSET = 10;
var BRICK_SPACING = 2;
var NUM_BRICKS_PER_ROW = 10;
var NUM_TOTAL_BRICKS = 0;
var BRICK_HEIGHT = 10;
var SPACE_FOR_BRICKS = getWidth() - (NUM_BRICKS_PER_ROW + 1) * BRICK_SPACING;
var BRICK_WIDTH = SPACE_FOR_BRICKS / NUM_BRICKS_PER_ROW;
var BRICK_COLOR = 1;
 
var brick;
var brickX = 0 + BRICK_SPACING;
var brickY = 0 + BRICK_TOP_OFFSET;

 
/* Constants for ball and paddle */
var paddle;
var PADDLE_WIDTH = 80;
var PADDLE_HEIGHT = 15;
var PADDLE_OFFSET = 10;
 
var ball;
var BALL_RADIUS = 15;
var BALL_START_X = getWidth() / 2;
var BALL_START_Y = getHeight() / 2;
var dx = 4;
var dy = 4;
 

function start(){
    drawRows();
}
 
//Bricks
function drawRows(){
   
    while(NUM_TOTAL_BRICKS < NUM_BRICKS_PER_ROW){
        brick = new Rectangle(BRICK_WIDTH, BRICK_HEIGHT); 
        brick.setPosition(brickX, brickY); 
       
        if(BRICK_COLOR == 1 || BRICK_COLOR == 2){
            brick.setColor(Color.red);
        }else if(BRICK_COLOR == 3 || BRICK_COLOR == 4){
            brick.setColor(Color.orange);
        }else if(BRICK_COLOR == 5 || BRICK_COLOR == 6){
            brick.setColor(Color.green);
        }else if(BRICK_COLOR == 7 || BRICK_COLOR == 8){
            brick.setColor(Color.blue);
        }
       
        add(brick);
        brickX += BRICK_WIDTH + BRICK_SPACING;
        NUM_TOTAL_BRICKS++;
       
        if(NUM_TOTAL_BRICKS >= NUM_BRICKS_PER_ROW && CURRENT_ROW != NUM_ROWS){
            brickY += BRICK_HEIGHT + BRICK_SPACING;
            brickX = 0 + BRICK_SPACING;
            CURRENT_ROW++;
            BRICK_COLOR++;
            NUM_TOTAL_BRICKS = 0;
        }
    }
}
