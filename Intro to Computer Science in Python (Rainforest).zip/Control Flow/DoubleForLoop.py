# Check out what this program prints. The
# spaces in the print on line 9 make it
# a little easier to visualize what's going
# on with each for loop.

for i in range(4):
    print "Outer for loop: " + str(i)
    for j in range(4):
        print "    Inner for loop: " + str(j)
