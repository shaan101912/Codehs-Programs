# This prints ten numbers - 0 through
# 9. When we give range one number,
# it starts at zero and goes up to
# BUT NOT INCLUDING that number.
for i in range(10):
    
    # Inside the for loop, we can
    # treat i like a normal integer
    # variable.
    print i
