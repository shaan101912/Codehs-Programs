"""
This Program prints the full name of a person
"""

#Insert Parts of your name
first_name = input("Enter your first name: ")
middle_name = input("Enter your middle name: ")
last_name = input("Enter your last name: ")


full_name = first_name + " " + middle_name + " " + last_name
print full_name
