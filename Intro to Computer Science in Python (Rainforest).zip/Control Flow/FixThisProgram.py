brought_food = True
brought_drink = False

# These lines don't work! Fix them so that they do.
print "Did the person bring food? " + str(brought_food)
print "Did the person bring a drink? " + str(brought_drink)
