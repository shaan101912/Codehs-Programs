can_juggle = True

# The code below has problems. See if
# you can fix them!
if can_juggle: 
    print "I can juggle!"
else:
    print "I can't juggle."
