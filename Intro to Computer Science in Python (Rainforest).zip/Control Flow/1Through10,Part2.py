# If we want to print the numbers
# 1 through 10, we have to give
# range two numbers - a start and
# an end. Once again, range goes up
# to BUT NOT INCLUDING the end.
for i in range(1, 11):
    print i
