def retrieve_positive_number():
    while (True):
        try:    
            positive_numb = int(input("Input a positive number: ")) 
            
            if positive_numb > 0:
                print positive_numb
                break
            else:
                continue
        
        except ValueError:
            print "That wasn't an integer!"
            
        
        

retrieve_positive_number()
