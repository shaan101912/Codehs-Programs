has_ticket = True
name_on_guest_list = False

print "has_ticket: " + str(has_ticket)
print "name_on_guest_list: " + str(name_on_guest_list)

cannot_enter_concert = not (has_ticket or name_on_guest_list)

print "cannot_enter_concert: " + str(cannot_enter_concert)

# Here is another version of the same boolean
# expression, expanded according to De Morgan's
# Law.
cannot_enter_concert = not has_ticket and not name_on_guest_list

print "cannot_enter_concert (expanded): " + str(cannot_enter_concert)
