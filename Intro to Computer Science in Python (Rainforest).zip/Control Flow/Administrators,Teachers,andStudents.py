role = input("What is your role at this school? ")

# The role must be teacher, administrator, or
# student. If it is none of these, the program
# will say so.
if role == "teacher" or role == "administrator":
    print "You get a key to this classroom!"
elif role == "student":
    print "You do not get a key."
else:
    print "You can only be a teacher, an administrator, or a student!"
