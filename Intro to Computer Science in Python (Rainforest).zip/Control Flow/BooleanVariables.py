is_correct = True
is_validated = False

print is_correct
print is_validated

print type(is_correct)
print type(is_validated)
