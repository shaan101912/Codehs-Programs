# If we declare a variable before defining
# a function, the function CAN access
# that variable, but it cannot change it.

my_variable = 1.5

def print_something():
    print my_variable + 3.2

print_something()
