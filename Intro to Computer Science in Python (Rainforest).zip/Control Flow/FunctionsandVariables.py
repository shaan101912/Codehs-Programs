# When you declare variables in
# a function, they ONLY exist in
# that function.
def print_something():
    x = 10
    print x

# In this part of the program, outside
# the function, we do NOT have a variable
# called x.
#
# However, we can call print_something,
# and it will be able to print its
# variable called x.
print_something()
