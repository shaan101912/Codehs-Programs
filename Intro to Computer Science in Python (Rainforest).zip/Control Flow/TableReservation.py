"""
This program determines whether or not
someone has a reservation in their name.
"""

Roger = str("Roger")

name = input(str("What is your name? "))

if name == Roger:
    print "Right this way!"
else:
    print "Sorry, we don't have a reservation under that name."
