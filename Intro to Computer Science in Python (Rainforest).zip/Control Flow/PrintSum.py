def sum(x,y):
    print (int(x) + int(y))
    
sum(12,12)
