# Here is a simple function that
# prints a greeting.
def greeting():
    print "Hi there!"
    print "Nice to meet you!"

# Note that the code above does not
# run until we call the function, like
# so:
greeting()
