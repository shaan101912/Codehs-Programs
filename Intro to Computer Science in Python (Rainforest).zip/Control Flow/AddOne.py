# Your code here...
def add_one(x):
    sum = x + 1
    return sum
    
print(add_one(5))
