has_food = False
has_drink = False

# The line below isn't quite right...
if not has_food or not has_drink:
    print "You can come into the classroom."
else:
    print "You cannot come into the classroom."
