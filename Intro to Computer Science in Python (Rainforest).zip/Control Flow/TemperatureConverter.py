# Write your function for converting Celcius to Fahrenheit here.
# Make sure to include a comment at the top that says what the
# function does!
def cel_to_far(x):
    farn = 1.8 *x + 32
    return farn

# Now write your function for converting Fahrenheit to Celcius.
# This should also have a comment at the top.
def far_to_cel(x):
    celc = (x-32)/1.8
    return celc

# Now write some code that uses those functions here.
print(cel_to_far(round(12.44,2)))

print(far_to_cel(round(89.12,2)))
