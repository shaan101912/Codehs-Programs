"""
This program determines whether a number
entered by the user is positive, zero, or
negative.
"""

number = int(input("What number?"))

if number > 0:
    print "This Number is Positive"
elif number == 0:
    print "This Number is Zero"
else:
    print "This Number is Negative"
    

