"""
This program determines whether or not
someone is old enough to vote in the U.S.
"""

age = input("What is your Age?")

if age >=18:
    print "You are old enough to vote!"
else:
    print "You are not old enough to vote."
