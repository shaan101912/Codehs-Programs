# If you TRY to change an outside variable
# from within a function, that actually
# makes another variable!
#
# In this program, printSomething has its
# own variable called z. It can no longer
# access the outer variable called z.
#
# This is called shadowing. You can think
# of printSomething's variable z as
# shadowing the outer variable z. The
# outer variable z is eclipsed by the
# one in printSomething.

z = 6.5

def print_something():
    z = "hi"
    
    # This line refers to the variable
    # z on line 18.
    print z * 3

print_something()

# This line refers to the variable z on
# line 15.
print z * 3
