"""
This program asks the user for their name
and age. It handles the case where the
user fails to enter a valid integer for
their age.
"""

# No exception handling needed here...
name = input("Enter your name: ")

# Let's give age a default value, in case
# we can't get the user to enter an integer.
age = -1

try:
    age = int(input("Enter your age: "))
except:
    print "That wasn't an integer."

print "Name: " + name
print "Age: " + str(age)
