num_categories = 3
tests_per_categories = 3


for i in range(num_categories):
    name_cat = input("Enter a Category: ")
 
    str = ""
    
    for j in range(tests_per_categories):
        name = input("Enter something in that category: ")
        str += name  
    
    print name_cat + ": " + str 
    

