def print_p():
    # Change this function so that it prints
    # the letter P!
    print "*****"
    print "*   *"
    print "*****"
    print "*"
    print "*"

def print_y():
    print "*   *"
    print " * * "
    print "  *  "
    print "  *  "
    print "  *  "

def print_t():
    # Change this function so that it prints
    # the letter T!
    print "*****"
    print "  *"
    print "  *"
    print "  *"
    print "  *"

def print_h():
    print "*   *"
    print "*   *"
    print "*****"
    print "*   *"
    print "*   *"

def print_o():
    print " *** "
    print "*   *"
    print "*   *"
    print "*   *"
    print " *** "

def print_n():
    print "*   *"
    print "**  *"
    print "* * *"
    print "*  **"
    print "*   *"
    
# Now, call the functions in the right
# order to spell PYTHON!

print_p()
print_y()
print_t()
print_h()
print_o()
print_n()
