"""
This program first asks the user how
many numbers they want to total. It then
asks them for that many numbers and
reports the total of the numbers.
"""

total = 0
number_of_numbers = int(input("How many numbers would you like to sum? "))

# Note that you can use a variable in
# range instead of a literal number.
for i in range(number_of_numbers):
    next = int(input("Enter a number: "))
    total = total + next

print("Sum: " + str(total))
