# You can make some parameters optional.
# If they are not provided, they can be
# given default values. This looks a little
# funky - kind of like assigning a variable
# in a function's parentheses - but it
# works!
#
# Note that the parameters with default
# values have to come after the parameters
# without default values.
def print_two_numbers(x, y = 10):
    print "First number: " + str(x)
    print "Second number: " + str(y)

print_two_numbers(5)
print_two_numbers(7, 8)
