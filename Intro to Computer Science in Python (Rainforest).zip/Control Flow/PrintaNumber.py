# This function takes a single
# parameter and prints it. Note
# that even though it is called
# print_number, the parameter
# doesn't have to be a number.
# Try calling it and passing it
# a string instead, and see what
# happens.
def print_number(x):
    print x

print_number(12)
print_number(15)
