has_bike = True
has_helmet = False

print "has_bike: " + str(has_bike)
print "has_helmet: " + str(has_helmet)

cannot_bike = not (has_bike and has_helmet)

print "cannot_bike: " + str(cannot_bike)

# Here is another version of the same boolean
# expression, expanded according to De Morgan's
# Law.
cannot_bike = not has_bike or not has_helmet

print "cannot_bike (expanded): " + str(cannot_bike)
