"""
This program simulates a single transaction -
either a deposit or a withdrawal - at a bank.
"""

initial_balance = 1000

deposit_or_withdrawal = input("Would you like to take out a deposit or withdrawl: ")

if deposit_or_withdrawal == "deposit":
    int_1 = int(input("Enter amount: $"))
    print "Final Balance: $" + str(initial_balance + int_1)
elif deposit_or_withdrawal == "withdrawal":
    int_2 = int(input("Enter amount: $"))
    if int(initial_balance - int_2) < 0:
        print "You cannot have a negative balance!"
    else:
        print "Final Balance: $" + str(initial_balance - int_2)
else:
    print "Invalid transaction"
    


    
