total_score = 0

for i in range(3):
    score1 = int(input("What is the Test Score?: "))
    total_score += int(score1)
    
average_score = total_score/3

print average_score
    
