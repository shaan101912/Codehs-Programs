# Can you predict what this program prints?
#
# What if you changed continue to break?

for i in range(3):
    if i == 1:
        continue
    print i

print 3
