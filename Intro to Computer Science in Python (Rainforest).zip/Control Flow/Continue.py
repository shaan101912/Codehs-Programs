# This for loop only prints 0 through 4
# and 6 through 9.
#
# Note that i is still incremented when
# we skip back to the top of the for loop
for i in range(10):
    if i == 5:
        continue
    print i
