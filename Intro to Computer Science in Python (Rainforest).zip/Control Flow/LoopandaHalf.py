# You can also use break and continue in
# a while loop.

magic_number = 10

# This would usually be an infinite loop,
# since True is always True! But with the
# use of break, we can force it to stop
# at a certain point.
while True:
    guess = int(input("Guess my number: "))
    if guess == magic_number:
        print "You got it!"
        break
    
    # This line is NOT reached if the condition
    # on line 12 was True.
    print "Try again!"

# This part of the program is reached only when
# we have broken out of the while loop.
print "Great job guessing my number!"
