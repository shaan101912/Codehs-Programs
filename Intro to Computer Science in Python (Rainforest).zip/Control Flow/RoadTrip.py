num_cities = int(input("Enter how many cities are on your route: "))
num_days = int(input("How many days is your road trip? "))

# The second part of the if statement is only evaluated
# if the first part - num_cities > 0 - is True. If the
# first part is False, the whole expression will be False,
# regardless of what the second part of the expression
# evaluates to.
if num_cities > 0 and num_days / num_cities > 0:
    print "You can spend at least one night in each city!"
else:
    print "Either you don't have enough days, or this route has zero cities."
