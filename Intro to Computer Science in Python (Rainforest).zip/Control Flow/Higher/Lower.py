# Set your secret number to 3.3312 to grade your code
secret_number = round(3.3312,4)

while True:
    guess_numb = float(input("Enter a guess:  "))
    if round(guess_numb,5) > round(secret_number,5):
        print "Too High!"
    elif round(guess_numb,5) < round(secret_number,5):
        print "Too low!"
    else:
        print "Correct!"
        break

