"""
This is a program that has a boolean variable that
represents whether or not it is raining outside. 
It prints "I'm going to eat lunch inside!" if it is 
raining, and "I'm going to eat lunch outside!" if it 
is not raining.
"""
is_raining_outside = False

if is_raining_outside:
    print "I'm going to eat lunch inside!"
else:
    print "I'm going to eat lunch outside!"
    
