# Write your function for converting Celcius to Fahrenheit here.
# Make sure to include a comment at the top that says what the
# function does!
def cel_to_far(x):
    farn = 1.8 *x + 32
    return farn

# Now write your function for converting Fahrenheit to Celcius.
# This should also have a comment at the top.
def far_to_cel(x):
    celc = (x-32)/1.8
    return celc


which_one = str(input("What would you like to convert -fahrenheit-, or -celcius-    "))
if (which_one == "fahrenheit"):
    try:    
        far_to_cel1 = float(input("What number would you like to convert?(round it 2 decimal points): "),2)   
        print(far_to_cel(far_to_cel1))
    except ValueError: 
        print "Only print numbers"
else:
    try:
        cel_to_far1 = float(input("What number would you like to convert? (round it 2 decimal points): "),2)   
        print(cel_to_far(cel_to_far1))
    except ValueError:
        print "Only print numbers"
  
