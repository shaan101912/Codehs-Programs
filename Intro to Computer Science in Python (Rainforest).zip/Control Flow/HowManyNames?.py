name = ""

numb_names = int(input("How many names do you have? "))

for i in range(numb_names):
    name1 = str(input("What is name?: "))
    name = name + " " + name1
    


print name



