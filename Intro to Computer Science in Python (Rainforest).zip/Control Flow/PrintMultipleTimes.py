# Your code here...

def print_num_times(str,x):
    for i in range(x):
        print str
        

print_num_times("Hello",5)
