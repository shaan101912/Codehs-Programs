# Amount of food and number of people
tons_of_food = round(0.07,5)
num_people = round(25,5)

# Determine how much food each person gets
tons_of_food_per_person = tons_of_food / num_people
print tons_of_food_per_person

# Ask the user how much food they took
tons_taken = float(input("How many tons of food did you take? "))
if round(tons_taken,5) == round(tons_of_food_per_person,5):
    print "Good job, you took the right amount of food!"
else:
    print "You took the wrong amount of food!"
