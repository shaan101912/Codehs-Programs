"""
This program asks the user for three ingredients,
three amounts, and a number of servings, and
determines how much of each ingredient is needed
to serve the specified number of servings.
"""

ingredient_1 = input("Enter ingredient 1: ")
ingredient_2 = input("Enter ingredient 2: ")
ingredient_3 = input("Enter ingredient 3: ")

ounces_ingredient_1 = float(input("How many ounces of ingredient 1?: ")) 
ounces_ingredient_2 = float(input("How many ounces of ingredient 2?: "))
ounces_ingredient_3 = float(input("How many ounces of ingredient 3?: "))

num_servings = int(input("How many servings do you want?: "))

num_1 = (ounces_ingredient_1 * num_servings)
num_2 = (ounces_ingredient_2 * num_servings)
num_3 = (ounces_ingredient_3 * num_servings)

print "Total ounces of " + str(ingredient_1) +": " + str(num_1)
print "Total ounces of " + str(ingredient_2) +": " + str(num_2)
print "Total ounces of " + str(ingredient_3) +": " + str(num_3)
