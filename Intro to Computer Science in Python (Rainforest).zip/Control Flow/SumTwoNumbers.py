# Your code below...
# Your code here...
def sum(x,y):
    sum_1 = x + y
    return sum_1
    
print(sum(5,15))
