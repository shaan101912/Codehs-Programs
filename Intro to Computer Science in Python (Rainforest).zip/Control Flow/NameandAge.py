# This function takes two arguments. It expects
# the first to be a string and the second to be
# a number.
def print_name_and_age(name, age):
    print "Hi, my name is " + name + " and I am " + str(age) + " years old."

print_name_and_age("Sierra", 34)
print_name_and_age("Marcus", 19)
