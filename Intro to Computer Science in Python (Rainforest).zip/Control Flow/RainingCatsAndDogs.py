def print_cat():
    print " |\_/|"
    print " 'o.o'"
    print"=( _ )="
    
def print_dog():
    print"   /)___"
    print"  /     O|___"
    print" /           )"
    print"/       )___/"
    

print_cat()
print_dog()
print_cat()
print_dog()
