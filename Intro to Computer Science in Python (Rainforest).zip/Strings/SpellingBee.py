word = "eggplant"

# Give the word to spell
print "Your word is: " + word + "."

# Spell the word with a for loop here!


for i in range(len(word)):
    print(word[i] + "!")
