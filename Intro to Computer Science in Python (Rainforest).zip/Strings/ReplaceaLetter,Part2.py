def replace_at_index (xs,y,w): 
    word = xs
    return word[:(y)] + w + word[y+1:]


s = replace_at_index("eggplant", 0,"rogic")
print s
