# Remember the second version of a for
# loop over a string? It used the Python
# keyword "in". You can also use this
# keyword in an if statement to determine
# whether a particular character is in
# a string somewhere.

word = "eggplant"

if "e" in word:
    print "Found an e in " + word
else:
    print "Didn't find an e in " + word

letter = "y" or "g"
if letter in word:
    print "Found " + letter + " in " + word
else:
    print "Didn't find " + letter + " in " + word
