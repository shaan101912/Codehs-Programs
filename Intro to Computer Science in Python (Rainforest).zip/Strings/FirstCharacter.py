def first_character(my_string1):
    return my_string1[0]    
    
    

def all_but_first_character(my_string2):
    return my_string2[1:]
    
 
 
my_string = "hello"   
print first_character(my_string)
print all_but_first_character(my_string)
    
