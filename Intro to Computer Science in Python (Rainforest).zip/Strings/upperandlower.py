# A method is sort of like a function,
# except you call it ON a particular thing.
# So, instead of getting the uppercase version
# of a string like this:
#
# second_string = upper(first_string)
#
# ... you do it like this:
#
# second_string = first_string.upper()
#
# This is calling the upper method on
# the variable first_string.

first_string = "hello"
second_string = first_string.upper()
third_string = second_string.lower()

print first_string
print second_string
print third_string
