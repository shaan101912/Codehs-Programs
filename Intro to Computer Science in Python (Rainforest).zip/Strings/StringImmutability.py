my_string = "hello!"

# This line is ok, because it replaces
# a string.
my_string = "hi!"

# You can also create new strings out of
# old strings, like this.
my_other_string = my_string[:2]

# This line, however, will cause an error,
# because it tries to change a string.
my_string[0] = "H"
