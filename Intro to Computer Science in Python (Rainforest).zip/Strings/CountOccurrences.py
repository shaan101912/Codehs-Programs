def times_it_occurs(first,second):
    num = 0
    for letter in first:
        if letter == second:
            num = num + 1
            print num
            
times_it_occurs("hello", "e")
