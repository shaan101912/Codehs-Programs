# The len function is a built-in function
# in Python that can be used to get the
# length of a string, like so.
#
# Note that a space character is still a
# character, and it still contributes to
# the length of a string!

print len("hello")
print len("")
print len("a b c d e")

# Note that the maximum possible index into
# a string is not the length, but one less
# than the length (because indexes start at
# 0).

my_string = "hello"
bad_index = len(my_string)

# This line causes an error.
print my_string[bad_index]
