word = str(input("Enter a string of lowercase letters: "))


if "e" in word:
    print "Found a vowel"
elif "a" in word:
    print "Found a vowel"
elif "i" in word:
    print "Found a vowel"
elif "o" in word:
    print "Found a vowel"
elif "u" in word:
    print "Found a vowel"
else:
    print "Didn't find a vowel"
