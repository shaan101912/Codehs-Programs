def remove_all_from_string (xs,lat): 
    word = xs
    num = 0
    for letter in word:
        if letter == lat:
            num = num + 1

    while num > 0:
        print remove(num,word)
        
    
    
def remove(x,y):
        final_word = ""
        index = y.find(y)
        final_word = y[:(index)] + "" + y[index+1:]
        x = x - 1
        return final_word
     



print remove_all_from_string("hello","o")

