# You can access each character in a string,
# in order, using a combination of a for loop,
# the range function, and the len function.

my_string = "hello"
for i in range(len(my_string)):
    # Use i as an index! It will be
    # set to every integer starting
    # at 0 and going up to but not
    # including the length of the
    # string.
    print my_string[i]

# You can also use another type of
# for loop to iterate through a string
# more directly.

for letter in my_string:
    # letter is now a variable that will
    # be set to "h", then "e", etc.
    print letter
