my_string = "doghouse"

# print "h" here
print my_string[3]

# print "e" here
print my_string[7]

# print "dog" here
print my_string[:3]

# print "house" here
print my_string[3:]

# print "ou" here
print my_string[4:6]
