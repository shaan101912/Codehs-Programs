def replace_at_index (xs,y): 
    word = xs
    return word[:(y)] + "-" + word[y+1:]


print replace_at_index("eggplant", 4)

