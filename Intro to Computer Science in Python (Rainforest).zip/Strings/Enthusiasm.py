def add_enthusiasm(x):
    first_string = x
    second_string = first_string.upper()
    second_string = second_string + "!"
    return second_string
    
print add_enthusiasm("I like dogs")
    

    


