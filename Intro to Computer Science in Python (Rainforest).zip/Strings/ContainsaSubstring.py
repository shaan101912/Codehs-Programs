# You can also determine if a string
# contains a particular substring!

if "abra" in "abra cadabra":
    print "abra is in abra cadabra!"
else:
    print "abra is not in abra cadabra."
