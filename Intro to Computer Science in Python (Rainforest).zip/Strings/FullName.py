# Ask the user for their first and last
# names.
first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

# Print the user's full name below...

print first_name + " " + last_name
