# The strip method returns a new string equal
# to the old string with leading and trailing
# whitespace characters (spaces, tabs, etc.)
# removed.

s = "    hi there    "
print s
print s.strip()
