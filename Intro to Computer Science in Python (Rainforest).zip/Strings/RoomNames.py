"""
Ask the user for the building name
and room number. Output an abbreviation
that identifies the room.

Take the first two letters of the
building name, and concatenate it with
the room number.
"""

building_name = input("Building name: ")

# This can just be a string, because even
# if it's a number, we're never going
# to do anything numerical with it.
room_number = input("Room number: ")

abbreviation = building_name[:2] + room_number
print abbreviation
