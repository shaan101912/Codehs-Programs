# The swapcase method returns a new string equal to
# the old string, but with uppercase letters turned
# into lowercase letters and vise versa.

s = "PyThOn"
print s
print s.swapcase()
