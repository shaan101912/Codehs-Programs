def make_fencepost():
    forward(10)
    left(90)
    forward(30)
    left(180)
    forward(30)
    left(90)
    
for i in range(5):
    make_fencepost()
