def draw_diamond():
    left(45)
    for i in range(4):
        forward(20)
        left(90)
    
    right(45)
    
    
    
for i in range (4):
    draw_diamond()
    forward(50)
    
