for i in range(4):
    left(90)
    forward(30)
    right(90)
    forward(30)


left(90)
