def draw_edge():
    forward(50)
    left(90)

for i in range(4):
    draw_edge()
