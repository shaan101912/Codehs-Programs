def draw_black_edge():
    color("black")
    forward(50)
    left(90)
    
def draw_red_edge():
    color("red")
    forward(50)
    left(90)
    
for i in range(2):
    draw_red_edge()
    draw_black_edge()
    
