def draw_diamond():
    left(45)
    for i in range(4):
        forward(20)
        left(65)
    
    right(45)
    
    
    
for i in range (20):
    draw_diamond()
    forward(50)
    

