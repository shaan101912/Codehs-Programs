color("red")

forward(50)
left(90)

forward(50)
left(90)

forward(50)
left(90)

forward(50)
