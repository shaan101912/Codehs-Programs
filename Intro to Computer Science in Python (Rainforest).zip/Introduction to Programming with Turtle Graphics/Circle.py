for i in range(360):
    forward(1)
    left(1)
