for i in range(3):
    forward(50)
    left(120)
