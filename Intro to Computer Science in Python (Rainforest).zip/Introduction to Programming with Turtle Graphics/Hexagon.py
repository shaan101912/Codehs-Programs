for i in range(6):
    forward(50)
    left(60)
