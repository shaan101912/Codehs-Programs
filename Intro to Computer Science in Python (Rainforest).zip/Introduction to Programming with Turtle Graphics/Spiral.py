for i in range(40):
    forward(i * 10)
    left(90)
