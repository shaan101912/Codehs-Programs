print "hello " + ", world!"
print "a" + "b" + "c"
print "hi" * 3

print "hi" + str(3)
print "My bike has " + "6" + " gears."
