a = 10
print a

c = 20
print c

b = c
print b


d = a + b
print d

f = 50

e = f + d
print e
