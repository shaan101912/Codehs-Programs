print "(\___/)"
print " \* */"
print "  \ /"
print "   o"
