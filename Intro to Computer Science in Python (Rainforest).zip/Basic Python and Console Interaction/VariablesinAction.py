greeting = "Hi there!"
num = 3
value = num

print greeting
print num
print value
