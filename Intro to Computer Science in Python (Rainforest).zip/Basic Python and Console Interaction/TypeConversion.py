x = input("Enter a number: ")
print type(x)

x = int(x)
print type(x)

print x + 3
