instrument = "kazoo"
age = 7

print "I have played the " + instrument + " since I was " + str(age) + " years old."
