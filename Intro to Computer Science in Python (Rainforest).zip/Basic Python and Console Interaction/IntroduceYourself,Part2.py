name = "shaan"
age = "16"

print "Hi! Name is " + str(name) + " and I am " + str(age) + " years old"
