noice = "noice"
ten = 10

print noice
print ten
