print -5 + 4 * 2 % 3 - 1
print -5 + 4 * 2 % (3 - 1)

x = 3
y = 7
z = x * - (y - 1) % 4

print z
