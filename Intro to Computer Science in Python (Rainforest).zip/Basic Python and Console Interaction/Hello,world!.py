print "Hello, world!"
