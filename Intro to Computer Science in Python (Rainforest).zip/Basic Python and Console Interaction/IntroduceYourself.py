print "My Name is Shaan"
print"I Like Computers, Cars and photography"
