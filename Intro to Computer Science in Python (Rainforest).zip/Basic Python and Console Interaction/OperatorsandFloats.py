x = 4.1
y = 5.2
z = 6

print "x + y = "  + str(x + y)
print "z * 3 = "  + str(z * 3)
print "x - z = "  + str(x - z)
print "z / x = "  + str(z / x)
print "y ** x = " + str(y ** x)
print "z % y = "  + str(z % y)
print "-x = "     + str(-x)
