age = int(input("what is your age: "))

number_of_candles = age + 1

print "Will need " + str(number_of_candles) + " candles for your birthday cake!"
