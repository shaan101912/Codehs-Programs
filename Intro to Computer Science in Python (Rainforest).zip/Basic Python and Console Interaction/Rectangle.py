length = 10
width = 5

print "Area: " + str(length*width)
print "Perimeter: " + str((length*2) + (width*2))
