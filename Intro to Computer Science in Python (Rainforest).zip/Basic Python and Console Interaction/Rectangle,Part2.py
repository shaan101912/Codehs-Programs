length = int(input("Lenght?: "))
width = int(input("Width?: "))

print "Area: " + str(length*width)
print "Perimeter: " + str((length*2) + (width*2))
