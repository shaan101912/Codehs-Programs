import React, { Component } from 'react';
import { View, WebView, StatusBar } from 'react-native';

export default class App extends Component {
    render() {

        var webViewCode = `
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript" src="https://static.codehs.com/gulp/5a59bdd3359d0c07da8e9c78dfa0f484c5ba80be/chs-js-lib/chs.js"></script>

<style>
    body, html {
        margin: 0;
        padding: 0;
    }
    canvas {
        margin: 0px;
        padding: 0px;
        display: inline-block;
        vertical-align: top;
    }
    #btn-container {
        text-align: center;
        padding-top: 10px;
    }
    #btn-play {
        background-color: #8cc63e;
    }
    #btn-stop {
        background-color: #de5844;
    }
    .glyphicon {
        margin-top: -3px;
        color: #FFFFFF;
    }
</style>
</head>

<body>
    <div id="canvas-container" style="margin: 0 auto; ">
        <canvas
        id="game"
        width="400"
        height="480"
        class="codehs-editor-canvas"
        style="width: 100%; height: 100%; margin: 0 auto;"
        ></canvas>
    </div>
    <div id="console"></div>
    <div id="btn-container">
        <button class="btn btn-main btn-lg" id="btn-play" onclick='stopProgram(); runProgram();'><span class="glyphicon glyphicon-play" aria-hidden="true"></span></button>
        <button class="btn btn-main btn-lg" id="btn-stop" onclick='stopProgram();'><span class="glyphicon glyphicon-stop" aria-hidden="true"></span></button>
    </div>

<script>
    var console = {};
    console.log = function(msg){
        $("#console").html($("#console").html() + "     " + msg);
    };

    var runProgram = function() {
        //Setting the Global Variables that are used through out the program
//This array is the word that player 2 is trying to guess, split into an array
var word = [];
//Declaring the variable for the amount of guesses player 2 will get
var amt_guesses;
//Declaring the array that contains the locations where the correctly guessed letter is located in the word player 1 inputed
var locations = [];
//Sets up the array for the sillhoutte word
var game_word = ["?","?","?","?","?","?"];
//The function where the code is read from first
function start()
{
    //Displays the Game rules function
    game_rules();
    //A loop and a half that replays until start or end is inputed 
    while (true)
    {
        //Variable that contains the user input
        var start =  readLine("Type : start : to begin the game or Type : end : to end the game: ").toLowerCase();
        //What happens when start is typed
        if (start == "start")
        {
            //The game function is called
            game();
            //Once the game function is called, the while loop is broken out of
            break;
        // If end is typed into the start variable    
        }else if (start == "end")
        {
            //The while loop is broken out of and the game is terminated
            break;
        }else
        {
            //The following is displayed is the user inputed anything but start or end
            println("You may have mistyped, Type : start : to begin the game or: end : to stop the game");
        }
    }
} 
//The function that displayes the game rules
function game_rules()
{
    //The following are the game rules that are displayed to the User
    alert("You are about to play a 2 player guessing game...");
    alert("Player 1 will begin by typing in a word that is 2 to 6 letters");
    alert("Player 2 will then select the difficulty, which will determine the amount of guesses given. The amount of guesses you have will then be displayed and a silhouette for the word will also be revealed");
    alert("Player 2 will be prompted to guess a letter and if it is correct the '?' in the silhouette word will be changed to the letter");
    alert("If player 2 guesses all the letters then he/she won!");
    alert("GOOD LUCK and HAVE FUN!");
}
//The function that determines the amount of guesses player 2 will recieve
function difficulty()
{
    //A loop and a half that will restate the prompy untill an acceptable outcome is typed by the user
    while (true)
    {
        //Variable that holds the difficulty the user wants to play at
        var diff = readInt("PLAYER 2: At what difficulty would you like to play at? Type - 1 - for Easy, Type - 2 - for Medium, and Type - 3 - for Hard: ");
        //If the user selects 1 which is the easy difficulty
        if (diff == 1)
        {
            //Player 2 gets an amount of of guesses that is 3 times the lenght of the word that player 1 inputed 
            amt_guesses = (word.length * 3); 
            break;
        }
        //If the user selects 2, the medium difficulty
        else if (diff == 2)
        {
            //Player 2 gets an amount of guesses that is 2 times the length of the word that player 1 inputed
            amt_guesses = (word.length * 2);    
            break;
        }
        //If the User selects 3, the Hard difficulty
        else if (diff == 3)
        {
            //Player 2 gets an amount of guesses that is the integer portion of 1.5 times the length of the word
            amt_guesses = Math.floor(word.length * 1.5);
            break;
        }
        else
        {
            //What is displayed if 1, 2, or 3 is not inputed by the user
            alert("You mistyped. Type - 1 - for Easy, Type - 2 - for Medium, and Type - 3 - for Hard:   ");
            //Sets the difficulty variable to an empty string
            diff = ("");
        }
    }
    //After the diffculty is selected, the amount of guess is displayed to the user
    alert("You have " + amt_guesses + " guesses");
}
//The function that adjusts the game_word array each time a correct guess is made
function gameWord(word,length,guess)
{
    for(var i = 0; i < length; i++)
    {
        //If the letter at a certain position in the word array is the same as player 2's guess...
        if (word[i] == guess) 
        {
            //then the '?" at that location is changed to the guess
            game_word[i] = guess;  
        }
    }
    //The current state of the game_word array joined to a string is printed
    alert(game_word.join(""));
}
//The function that runs the code used for player 2 guessing the code
function guess()
{
    //An array that will contain all the letters that player 2 has already guessed
    var guessed = [];
    //Runs the gueesing function the amount of times that was determined in the difficulty function
    for(var i = 0; i < amt_guesses; i++)
    {
        //Runs if the game_word array no longer contains '?' meaning the word has been successfully guessed
        if (all_blank(game_word,"?"))
        {
            //The user is told he/she have correctly guessed the word
            alert("YOU GUESSED THE WORD!");  
            break;
        }
        //Runs if the game_word still contains at least 1 '?' which means the game is still running
        else
        {    
            //variable for the user input that takes the input and splits it into an array
            var letter_guess = readLine("Guess a Letter: ").split(""); 
            //this variable combines the previous array into a string
            var guess_combined = letter_guess.join("");
            //this variable takes the previous string and removes all characters that are not in the alphabet
            var check = (guess_combined.replace(/[^a-z]/gi,'').split(""));
            //The code is run only if all the letters are in the alphabet, it checks by making sure no characters were removed from the letter_guess array
            if(letter_guess.length == check.length && letter_guess.length == 1)
            {
                //if the guess is a letter then the letter guessed will put pushed into the guessed array
                guessed.push(check);
                //The user is told each time how many guesses remain
                alert("You have " + (amt_guesses - i - 1) + " guesses left");
                //If the the guess is correct the following code is run
                if (contains(word,check))
                {
                    //if the guess is correct, the user is told so
                    alert("You guessed a letter!");
                    //Finds where in the word the guess is located 
                    location(word, check);
                    //adjusts the game_word array so the user can see where in the word the letter they guessed is located
                    gameWord(word,word.length,check)
                    //If a letter is guessed then the amount of guesses left is reported to the user
                    if (i >= 1)
                    {
                        println("  ");
                        alert("You already guessed the letter(s) " + guessed + ".");
                    }
                    //reset the letter_guess array for the next guess
                    letter_guess = [];
                    //the guess_combined string is reset for the next guess
                    guess_combined = ("");
                    //the check array is reset for the next guess
                    check = [];    
                }
                //If the guess is not correct the following code is run
                else
                {
                    //The current status of the game_word is displayed
                    alert(game_word.join(""));
                    //The user is told he/she did not guess the letter correctly
                    alert("You did not guess a letter. Try again.");
                    //If a guess had already been made then the remaining amount of guesses is deisplayed
                    if (i >= 1)
                    {
                        println("  ");
                        println("You already guessed the letter(s) " + guessed + ".");
                    }
                    //reset the letter_guess array for the next guess
                    letter_guess = [];
                    //the guess_combined string is reset for the next guess
                    guess_combined = ("");
                    //the check array is reset for the next guess
                    check = [];   
                }
            }
            //If anything but just 1 letter is guessed, the following code is run 
            else
            {
                //The user is told when he/she can only guess
                alert("You can only Guess 1 letter, nothing else"); 
                //reset the letter_guess array for the next guess
                    letter_guess = [];
                    //the guess_combined string is reset for the next guess
                    guess_combined = ("");
                    //the check array is reset for the next guess
                    check = [];   
            }
        }
    }
    //If all the guess had been used then the following code is run
    if(amt_guesses == 0)
    {
        //If the game_word array no longer contains any '?"
        if(all_blank(game_word,"?"))
        {
            println("  ");
            //The user is told he/she guessed the word
            alert("YOU GUESSED THE WORD!");    
        }
        //If the array does contain at least 1 '?'
        else
        {
            println("  ");
            //The user is told he/she did not guess the word
            alert("Sorry you did not guess the word, try again");
        }
    } 
}
//The array that determines if the game_word array has any '?' left in it
function all_blank(array,character)
{
    //The complete variable is set false to start
    var complete = false;
    //sets the all good variable to 0
    var all_good = 0;
    //runs the loop the amount of times equal to the length of the array called
    for(var i = 0; i < array.length; i++)
    {
        //If the current position in the array does not have the character called, in this case the question mark then 1 is added to the all_good variable
        if(array[i] != character)
        {
            all_good++;    
        }
    }
    //If the amount good is equal to the length of the array then that means no position in the array contains the character, the question mark in this case.
    if(all_good == array.length)
    {
        //the complete varialbe is set true if the array does not contain the character 
        complete = true;    
    }
    //the boolean status of the complete variable is returned
    return complete;
}
//function that takes player 2's letter guess and puts the location(s) at which the letter is located in the word he/she is trying to guess into an array 
function location(array, val) 
{
    //runs the loop the amount of times equal to the length of the array called
    for (var i = 0; i < array.length; i++)
    {
        //checks each position of the word array and if the letter is the same as the guess...
        if(word[i] == val)
        {
            //...then the numerical position is pushed into another array.
            locations.push(i);
        }
    }    
}
//Function that determines is a value is located in the array called
function contains(array, val)
{
    //Sets the has variable to false to start
    var has = false;
    //A loop that runs the code an amount of time equal to the length of the array called
    for(var i = 0; i < array.length; i++)
    {
        //if the value of the array at any psotion is equal to the value....
        if(array[i] == val)
        {
            //Then the has variable is set true which means the array does contain the value
            has = true;
        }
    }
    //The boolean status of the has variable is returned
    return has;
}
//The function that sets up the intitial input that player 1 performs
function game()
{
    //A loop and a half that keeps running the prompt untill the correct input is typed
    while(true)
    {
        //variable that contains the initial input of player 1 split into an array
        var input = readLine("PLAYER 1: What word would you like to Input, if you input a sentence the first word will be chosen.  In the word keep it 2 or more letters and 6 or less letters ").split("");   
        //Loop that reduces the original to one word, incase a space was inputted anywhere meaning it will reduce a sentence down to 1 word
        for(var i = 0; i < input.length; i++)
        {
            //If a space is detected anywhere then the loop is broken out of
            if(input[i] == " ")
            {
                break;
            }
            //If no space is seen then the character is placed into another array, the word array
            word.push(input[i]);
        }
        //This variable is the word array joined together into a string 
        var word_combined = word.join("");
        //This variable gets rid of all characters in the previous variable that are not part of the alphabet and split them into an array
        var onlyAlphabet = (word_combined.replace(/[^a-z]/gi,'').split(""));
        //This if statement makes sure the length of the original string and the one with only letters in the alphabet are the same which means the original string and therefore the word array conatains only characters in the alphabet
        if(onlyAlphabet.length == word.length)
        {
            //This if statement runs only if the word inputted is 2 to 6 letters long
            if (word.length >= 2 && word.length <= 6)
            {
                //The difficulty function is run: determines the amount of guesses player 2 will revieve
                difficulty();
                //The capitalization function is run: adjusts the letter in the word array to only be lowercase
                capitalization();
                //The setGameWord function is run: adjusts the length of the game_word array
                setGameWord();
                //The function where player 2 trys to guess the word is run
                guess();
                break;
            }
            //if the word is not the correct length the following code is run
            else 
            {
                //The user is told their imput is wrong and is told how to correct it
                println("You have too many or not enough letters in your word, keep it 2 or more and 6 or less")
                //The word array is reset so the while loop can be run again
                word = [];
                //The input array is reset so the while loop and run again
                input = [];
                //The word_combined string is reset
                word_combined = ("");
                //The onlyAlphabet array is reset
                onlyAlphabet = [];
            }
        }
        //If the user input contained characters that are not part of the alphabet the following code is run
        else
        {
            //The user is told what is wrong, being that his/her input contains a character or characters that are not part of the alphabet
            alert("Words only contain letters..."); 
            //The word array is reset so the while loop can be run again
            word = [];
            //The input array is reset so the while loop and run again
            input = [];
            //The word_combined string is reset
            word_combined = ("");
            //The onlyAlphabet array is reset
            onlyAlphabet = [];
        }
    }
}
//Takes the word array and makes all the letters lowercase
function capitalization()
{
    //Runs the correcting code for each letter in the word
    for(var i = 0; i < word.length; i++)
    {
        //Variable letter is the letter at the given position in the array
        var letter = word[i];
        //if the letter is not lowercase
        if (letter != letter.toLowerCase)
        {
            //Then the letter is made lowercase
            var lowercase = letter.toLowerCase();
            word[i] = lowercase;
        }
    }
}
//Function that reduces the game_word array to the length of the word that player 1 inputed
function setGameWord()
{
    //Since the max amount of letters is 6, the amount needed to remove is 6 minus the length of the word
    var amt_remove = (6 - (word.length));
    //Removed the last '?' from the game_word array for the amount of time determined in the previous variable
    for(var i = 0; i < amt_remove; i++)
    {
        //The 'pop' function removes the last element in an array
        game_word.pop();
    }
}


        if (typeof start === 'function') {
            start();
        }

        // Overrides setSize() if called from the user's code. Needed because
        // we have to change the canvas size and attributes to reflect the
        // user's desired program size. Calling setSize() from user code only
        // has an effect if Fit to Full Screen is Off. If Fit to Full Screen is
        // On, then setSize() does nothing.
        function setSize(width, height) {
            if (!true) {
                // Call original graphics setSize()
                window.__graphics__.setSize(width, height);

                // Scale to screen width but keep aspect ratio of program
                // Subtract 2 to allow for border
                var canvasWidth = window.innerWidth - 2;
                var canvasHeight = canvasWidth * getHeight() / getWidth();

                // Make canvas reflect desired size set
                adjustMarginTop(canvasHeight);
                setCanvasContainerSize(canvasWidth, canvasHeight);
                setCanvasAttributes(canvasWidth, canvasHeight);
            }
        }
    };

    var stopProgram = function() {
        removeAll();
        window.__graphics__.fullReset();
    }

    window.onload = function() {
        if (!false) {
            $('#btn-container').remove();
        }

        var canvasWidth;
        var canvasHeight;
        if (true) {
            // Get device window width and set program size to those dimensions
            setSize(window.innerWidth, window.innerHeight);
            canvasWidth = getWidth();
            canvasHeight = getHeight();

            if (false) {
                // Make room for buttons if being shown
                $('#btn-container').css('padding', '5px 0');
                canvasHeight -= $('#btn-container').outerHeight();
            }

            setCanvasAttributes(canvasWidth, canvasHeight);
        } else {
            // Scale to screen width but keep aspect ratio of program
            // Subtract 2 to allow for border
            canvasWidth = window.innerWidth - 2;
            canvasHeight = canvasWidth * getHeight() / getWidth();

            // Light border around canvas if not full screen
            $('#canvas-container').css('border', '1px solid #beccd4');

            adjustMarginTop(canvasHeight);
        }

        setCanvasContainerSize(canvasWidth, canvasHeight);

        if (true) {
            runProgram();
        }
    };

    // Set the canvas container width and height.
    function setCanvasContainerSize(width, height) {
        $('#canvas-container').width(width);
        $('#canvas-container').height(height);
    }

    // Set the width and height attributes of the canvas. Allows
    // getTouchCoordinates to sense x and y correctly.
    function setCanvasAttributes(canvasWidth, canvasHeight) {
        $('#game').attr('width', canvasWidth);
        $('#game').attr('height', canvasHeight);
    }

    // Assumes the Fit to Full Screen setting is Off. Adjusts the top margin
    // depending on the Show Play/Stop Buttons setting.
    function adjustMarginTop(canvasHeight) {
        var marginTop = (window.innerHeight - canvasHeight)/2;
        if (false) {
            marginTop -= $('#btn-container').height()/3;
        }
        $('#canvas-container').css('margin-top', marginTop);
    }
</script>
</body>
</html>
`;
        return (
            <View style={{ flex: 1 }}>
                <StatusBar hidden />
                <WebView
                    source={{html: webViewCode, baseUrl: "/"}}
                    javaScriptEnabled={true}
                    style={{ flex: 1 }}
                    scrollEnabled={false}
                    bounces={false}
                    scalesPageToFit={false}
                ></WebView>
            </View>
        );
    }
}
